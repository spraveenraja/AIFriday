"""Release Recovery Digital Twin (Executive Streamlit UI).

Design goals
- Restrained CIO-level executive dashboard
- Persistent left navigation + broad main panel
- All charts derive from the same deterministic scenario calculation result
- Baseline facts (incidents/defects/work items/margins) remain fixed and immutable
- Synthetic/unverified assumptions are visibly labeled
- No raw JSON exposed

Implementation note
- Uses Altair for polished charts (no matplotlib dependency).
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import altair as alt
import streamlit as st

from src.repositores.scenario_repo import RepoConfig, ScenarioRepository
from src.simulation.engine import (
    compute_escaped_defects,
    compute_incident_totals,
    compute_story_completion,
    simulate_release_recovery,
)
from src.agents.workflow import orchestrator_workflow
from src.data.db import DbConfig, connect, get_commitment_decision
from src.simulation.gates import evaluate_commitment_gates, load_evidence


PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data"
DB_PATH = PROJECT_DIR / "release_recovery_twin.sqlite"


def _streamlit_version() -> str:
    return st.__version__


def _altair_base_config() -> Dict[str, Any]:
    return {"font": "sans-serif", "labelLimit": 220, "titleLimit": 80}


def _bucket_by_weeks(dates: List[str], start: str, weeks: int) -> List[int]:
    """Deterministic week buckets for fixed historical baseline charts."""
    import datetime as _dt

    start_dt = _dt.datetime.strptime(start, "%Y-%m-%d").date()
    bucket_counts = [0 for _ in range(weeks)]
    for d in dates:
        dt = _dt.datetime.strptime(d, "%Y-%m-%d").date()
        delta_days = (dt - start_dt).days
        if delta_days < 0:
            continue
        week_idx = min(weeks - 1, delta_days // 7)
        if 0 <= week_idx < weeks:
            bucket_counts[week_idx] += 1
    return bucket_counts


def _extract_json_array(value: Any, default: Optional[list] = None) -> list:
    if default is None:
        default = []
    if value is None:
        return default
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else default
        except Exception:
            return default
    return default


def _seed_baseline_facts(baseline: Dict[str, Any]) -> Dict[str, Any]:
    story = compute_story_completion(baseline["work_items"])
    incidents = compute_incident_totals(baseline["incidents"])
    defects = compute_escaped_defects(baseline["defects"])
    return {
        "story_completion": story,
        "incident_totals": incidents,
        "escaped_defects": defects,
        "incident_rows": baseline["incidents"],
        "defect_rows": baseline["defects"],
        "work_item_rows": baseline["work_items"],
    }


def _scenario_defaults(baseline_work_items: List[Dict[str, Any]], baseline_meta: Dict[str, Any]) -> Dict[str, Any]:
    # Scenario assumptions (not baseline facts).
    # Keep defaults aligned with baseline facts / prompt targets.
    return {
        "preset_choice": "Controlled thin slice",
        "choice": "CTS",

        # capacity sliders
        "engineering_hours_per_week": 48,
        "borrowed_specialists_hours_per_week": 0,
        "qa_hours_per_week": 16,

        # spend
        "recovery_spend_cap": 250_000.0,

        # evidence minimums
        "canary_days": 3,
        "test_duration_weeks": 1.0,
        "rollback_duration": 0.25,
        "service_duration": 0.25,
        "human_approval_duration": 0.5,

        # scenario season assumption
        "weeks_until_customer_season": 4.0,

        # service coverage hard floor
        "support_min_floor_hours": 60.0,
        "support_hours_per_week_requested": 72.0 - 48.0,  # derived support at baseline

        # thresholds
        "max_escaped_high_sev_allowed": 0,
        "max_unresolved_blockers_allowed": 0,
        "planning_window_end_offset_weeks": 8.0,

        # decision scope model
        "cts_scope_fraction": 0.33,

        # borrowed specialists economics
        "borrowed_specialists_cost_per_hour": 600.0,

        # defect remediation
        "defect_remediation_effort": 8.0,

        # economics labeled synthetic/unverified
        "V_per_unit": 1_000_000.0,
        "value_decay_per_delay_week": 0.04,
        "internal_cost_engineering_per_hour": 150.0,
        "internal_cost_qa_per_hour": 120.0,
        "cost_per_incident": 50_000.0,
        "cost_per_escaped_high_sev_defect": 120_000.0,
        "delay_penalty_weeks_on_failure": 8.0,

        # deterministic model policy placeholders (synthetic)
        "Sp_policy_CTS": 0.7,
        "Sp_policy_FRZ": 0.4,
        "Sp_policy_BRS": 0.5,
        "Sp_policy_ALL": 0.2,
        "specialist_engineers_shared_with_support": 3,
        "weeks_until_customer_season_label": "synthetic assumption",

        # first wave selection (UI constraint only; engine does not yet use it)
        "first_wave_work_item_ids": [w["id"] for w in baseline_work_items[:3]],

        # model overhead deterministic default
        "dependency_overhead_fraction": 0.1,
    }


def _wave_to_scope_and_dependencies(
    *,
    baseline: Dict[str, Any],
    first_wave_work_item_ids: List[str],
    base_scope_remaining_units: float = 1.0,
    base_dependency_units: float = 0.4,
) -> Dict[str, Any]:
    """Deterministically map first-wave selection to scope + dependency inputs.

    This avoids wave selection being purely cosmetic.
    """
    work_items = baseline["work_items"]
    all_ids = [w["id"] for w in work_items if w["status"] in ("completed", "open")]
    if not all_ids:
        return {
            "scope_remaining_units": base_scope_remaining_units,
            "dependency_units": base_dependency_units,
            "dependency_exposure_fraction": 0.7,
        }

    selected_ids = [x for x in first_wave_work_item_ids if x in set(all_ids)]
    selected_count = len(selected_ids)
    total_count = len(all_ids)

    scope_fraction_selected = selected_count / total_count if total_count else 0.0
    scope_remaining_units = max(0.05, base_scope_remaining_units * max(scope_fraction_selected, 0.01))

    # Missing dependency ratio based on dependencies listed on selected work items.
    selected_items = [w for w in work_items if w["id"] in set(selected_ids)]
    all_selected_set = set(selected_ids)
    referenced_deps: List[str] = []
    missing_deps: List[str] = []
    for w in selected_items:
        deps = _extract_json_array(w.get("dependencies_json"), default=[])
        if not deps:
            deps = []
        referenced_deps.extend(deps)
        for d in deps:
            if d not in all_selected_set:
                missing_deps.append(d)

    total_refs = len(referenced_deps)
    missing_ratio = (len(missing_deps) / total_refs) if total_refs else 0.0
    dependency_units = base_dependency_units * (1.0 + missing_ratio)
    dependency_exposure_fraction = max(0.2, min(1.0, 0.7 + missing_ratio * 0.3))

    return {
        "scope_remaining_units": scope_remaining_units,
        "dependency_units": dependency_units,
        "dependency_exposure_fraction": dependency_exposure_fraction,
    }


def _preset_to_choice(preset_choice: str) -> str:
    mapping = {
        "Controlled thin slice": "CTS",
        "Full freeze": "FRZ",
        "Accelerate with borrowed specialists": "BRS",
        "Ship all remaining scope": "ALL",
    }
    return mapping[preset_choice]


def _apply_preset_to_state(state: Dict[str, Any]) -> Dict[str, Any]:
    preset = state["preset_choice"]
    choice = _preset_to_choice(preset)
    state = dict(state)
    state["choice"] = choice
    if choice == "CTS":
        state["cts_scope_fraction"] = 0.33
        state["borrowed_specialists_hours_per_week"] = 0
        state["recovery_spend_cap"] = state.get("recovery_spend_cap", 250_000.0)
    elif choice == "FRZ":
        state["cts_scope_fraction"] = 0.0
        state["borrowed_specialists_hours_per_week"] = 0
        state["recovery_spend_cap"] = 125_000.0
    elif choice == "BRS":
        state["cts_scope_fraction"] = 1.0
        state["borrowed_specialists_hours_per_week"] = 24
        state["recovery_spend_cap"] = 200_000.0
    elif choice == "ALL":
        state["cts_scope_fraction"] = 1.0
        state["borrowed_specialists_hours_per_week"] = 0
        state["recovery_spend_cap"] = 100_000.0
    return state


def _run_scenario(baseline: Dict[str, Any], scenario_state: Dict[str, Any]) -> Tuple[Dict[str, Any], Any]:
    choice = scenario_state["choice"]
    canary_weeks = float(scenario_state["canary_days"]) / 7.0

    # Deterministically map the first-wave selection into scope + dependency parameters.
    wave_map = _wave_to_scope_and_dependencies(
        baseline=baseline,
        first_wave_work_item_ids=scenario_state.get("first_wave_work_item_ids", []),
        base_scope_remaining_units=1.0,
        base_dependency_units=0.4,
    )

    # Deterministic engine inputs.
    sim_params = {
        "engineering_hours_per_week": float(scenario_state["engineering_hours_per_week"]),
        "support_hours_per_week": float(scenario_state["support_hours_per_week_requested"]),
        "support_min_floor": float(scenario_state["support_min_floor_hours"]),
        "specialist_engineers_shared_with_support": int(scenario_state["specialist_engineers_shared_with_support"]),
        "borrowed_specialists_hours_per_week": float(scenario_state["borrowed_specialists_hours_per_week"]),
        "borrowed_specialists_cost_per_hour": float(scenario_state["borrowed_specialists_cost_per_hour"]),
        "qa_hours_per_week": float(scenario_state["qa_hours_per_week"]),
        "defect_remediation_effort": float(scenario_state["defect_remediation_effort"]),
        "test_duration": float(scenario_state["test_duration_weeks"]),
        "canary_duration": canary_weeks,
        "rollback_duration": float(scenario_state["rollback_duration"]),
        "service_duration": float(scenario_state["service_duration"]),
        "human_approval_duration": float(scenario_state["human_approval_duration"]),
        "planning_window_end_offset_weeks": float(scenario_state["planning_window_end_offset_weeks"]),
        "recovery_spend_cap": float(scenario_state["recovery_spend_cap"]),
        "cts_scope_fraction": float(scenario_state["cts_scope_fraction"]),
        "max_escaped_high_sev_allowed": int(scenario_state["max_escaped_high_sev_allowed"]),
        "max_unresolved_blockers_allowed": int(scenario_state["max_unresolved_blockers_allowed"]),
        "weeks_until_customer_season": float(scenario_state["weeks_until_customer_season"]),

        # economics labeled synthetic/unverified
        "V_per_unit": float(scenario_state["V_per_unit"]),
        "value_decay_per_delay_week": float(scenario_state["value_decay_per_delay_week"]),
        "internal_cost_engineering_per_hour": float(scenario_state["internal_cost_engineering_per_hour"]),
        "internal_cost_qa_per_hour": float(scenario_state["internal_cost_qa_per_hour"]),
        "cost_per_incident": float(scenario_state["cost_per_incident"]),
        "cost_per_escaped_high_sev_defect": float(scenario_state["cost_per_escaped_high_sev_defect"]),
        "delay_penalty_weeks_on_failure": float(scenario_state["delay_penalty_weeks_on_failure"]),

        "Sp_policy_CTS": float(scenario_state["Sp_policy_CTS"]),
        "Sp_policy_FRZ": float(scenario_state["Sp_policy_FRZ"]),
        "Sp_policy_BRS": float(scenario_state["Sp_policy_BRS"]),
        "Sp_policy_ALL": float(scenario_state["Sp_policy_ALL"]),

        "recovery_hours_per_week": float(scenario_state["engineering_hours_per_week"]),
        "baseline_recovery_hours_per_week": 48.0,

        # wave-derived deterministic inputs (scenario assumptions)
        "scope_remaining_units": float(wave_map["scope_remaining_units"]),
        "dependency_units": float(wave_map["dependency_units"]),
        "dependency_exposure_fraction": float(wave_map["dependency_exposure_fraction"]),
        "dependency_overhead_fraction": float(scenario_state.get("dependency_overhead_fraction", 0.1)),
    }

    res = simulate_release_recovery(baseline=baseline, choice=choice, params=sim_params)
    return res.derived, res


def _chart_timeline_gantt(derived: Dict[str, Any]):
    ms = derived["schedule_milestones"]
    # Build deterministic bars relative to t=0.
    bars = [
        {"phase": "Dev", "start": 0, "end": ms["W_dev"]},
        {"phase": "Evidence (test+canary)", "start": ms["W_dev"], "end": ms["W_dev"] + ms["W_evidence_soft"]},
        {
            "phase": "Triage",
            "start": ms["W_dev"] + ms["W_evidence_soft"],
            "end": ms["W_dev"] + ms["W_evidence_soft"] + ms["W_triage"],
        },
        {
            "phase": "Remediation overflow",
            "start": ms["W_dev"] + ms["W_evidence_soft"] + ms["W_triage"],
            "end": ms["candidate_ready_end_weeks"] - ms["W_hard_tail"],
        },
        {
            "phase": "Rollback+Service+Approval",
            "start": ms["candidate_ready_end_weeks"] - ms["W_hard_tail"],
            "end": ms["candidate_ready_end_weeks"],
        },
    ]

    # Display-only rounding to keep axis tick labels readable.
    for b in bars:
        b["start"] = round(float(b["start"]), 2)
        b["end"] = round(float(b["end"]), 2)
    df = alt.Data(values=bars)
    chart = (
        alt.Chart(df)
        .mark_bar()
        .encode(
            y=alt.Y("phase:N", title="Milestone"),
            x=alt.X("start:Q", title="Weeks from t=0"),
            x2="end:Q",
            tooltip=[
                alt.Tooltip("phase:N", title="Milestone"),
                alt.Tooltip("start:Q", title="Start"),
                alt.Tooltip("end:Q", title="End"),
            ],
        )
    )
    return chart


def _chart_capacity_stacked(derived: Dict[str, Any]):
    hb = derived["hourly_capacity_breakdown"]
    data = [
        {"bucket": "Operations (engineering during dev)", "hours": hb["operations_engineering_hours_total"]},
        {"bucket": "Recovery (engineering during evidence+triage+overflow)", "hours": hb["recovery_engineering_hours_total"]},
        {"bucket": "QA (evidence window)", "hours": hb["qa_hours_total"]},
    ]
    df = alt.Data(values=data)
    return (
        alt.Chart(df)
        .mark_bar()
        .encode(
            x=alt.X("bucket:N", title=""),
            y=alt.Y("hours:Q", title="Hours", axis=alt.Axis(format="~s")),
            color=alt.Color("bucket:N"),
            tooltip=[
                alt.Tooltip("bucket:N", title="Bucket"),
                alt.Tooltip("hours:Q", title="Hours"),
            ],
        )
    )


def _format_checkpoint_weeks(w: float, *, max_display: float = 16.0) -> str:
    """Executive-safe display for large deterministic week values.

    Deterministic math can produce extreme values when capacity is near zero.
    We only adjust display (no math) to keep the executive UI readable.
    """
    try:
        wf = float(w)
    except Exception:
        return str(w)
    if wf <= max_display:
        return f"+{wf:.2f} weeks"
    return f"+> {max_display:.2f} weeks"


def main() -> None:
    st.set_page_config(page_title="Release Recovery Digital Twin", layout="wide")

    st.markdown(
        """
        <div style="
          width: 100%;
          background: linear-gradient(90deg, #102b3f, #087f8c);
          color: #ffffff;
          padding: 8px 14px;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.08);
          margin: 0 0 14px 0;
          font-weight: 760;
          letter-spacing: -0.01em;
          font-size: 14px;
        ">
          Digital Twin: The Next leap in Enterprise Service Resilience and Optimization
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.caption("CIO executive simulator • deterministic math • synthetic inputs labeled • Streamlit " + _streamlit_version())

    repository = ScenarioRepository(RepoConfig(db_path=str(DB_PATH), seed_data_dir=DATA_DIR))
    baseline = repository.init_db(reset_scenarios=st.sidebar.checkbox("Reset scenarios (explicit)", value=False))
    baseline_facts = _seed_baseline_facts(baseline)
    meta = baseline["meta"]

    if "scenario_state" not in st.session_state:
        st.session_state.scenario_state = _scenario_defaults(baseline["work_items"], meta)

    # Left pane navigation
    view = st.sidebar.radio(
        "Executive menu",
        [
            "Executive Decision",
            "Recovery Simulator",
            "Release & Defects",
            "Live Service",
            "Economics & Commitment",
        ],
        index=1,
    )

    # Run baseline and selected scenario deterministically.
    base_state = _scenario_defaults(baseline["work_items"], meta)
    base_state["choice"] = "CTS"
    base_state["preset_choice"] = "Controlled thin slice"
    base_state = _apply_preset_to_state(base_state)
    base_derived, _base_res = _run_scenario(baseline, base_state)

    # Scenario inputs UI (only in Recovery Simulator view)
    if view == "Recovery Simulator":
        # Presets
        preset_choice = st.radio(
            "Scenario preset",
            [
                "Controlled thin slice",
                "Full freeze",
                "Accelerate with borrowed specialists",
                "Ship all remaining scope",
            ],
            index=[
                "Controlled thin slice",
                "Full freeze",
                "Accelerate with borrowed specialists",
                "Ship all remaining scope",
            ].index(st.session_state.scenario_state["preset_choice"]),
            key="preset_choice_radio",
        )
        st.session_state.scenario_state["preset_choice"] = preset_choice
        st.session_state.scenario_state = _apply_preset_to_state(st.session_state.scenario_state)

        # Sliders
        st.markdown("### Control knobs (scenario assumptions)")
        engineering_hours = st.slider(
            "Recovery engineering hours per week",
            min_value=24,
            max_value=80,
            value=int(st.session_state.scenario_state["engineering_hours_per_week"]),
            step=1,
            key="engineering_hours_slider",
        )
        st.session_state.scenario_state["engineering_hours_per_week"] = float(engineering_hours)
        derived_support = 120 - engineering_hours
        st.caption(f"Derived support allocation from 120 total hours/week: {derived_support} hours/week")

        borrowed_hours = st.slider(
            "Borrowed specialists hours per week",
            min_value=0,
            max_value=40,
            value=int(st.session_state.scenario_state["borrowed_specialists_hours_per_week"]),
            step=1,
            key="borrowed_hours_slider",
        )
        st.session_state.scenario_state["borrowed_specialists_hours_per_week"] = float(borrowed_hours)

        qa_hours = st.slider(
            "QA hours per week",
            min_value=8,
            max_value=40,
            value=int(st.session_state.scenario_state["qa_hours_per_week"]),
            step=1,
            key="qa_hours_slider",
        )
        st.session_state.scenario_state["qa_hours_per_week"] = float(qa_hours)

        recovery_spend_cap = st.slider(
            "Recovery spend cap (synthetic/unverified)",
            min_value=0.0,
            max_value=2_000_000.0,
            value=float(st.session_state.scenario_state["recovery_spend_cap"]),
            step=25_000.0,
            key="spend_cap_slider",
        )
        st.session_state.scenario_state["recovery_spend_cap"] = recovery_spend_cap

        canary_days = st.slider(
            "Canary days",
            min_value=1,
            max_value=7,
            value=int(st.session_state.scenario_state["canary_days"]),
            step=1,
            key="canary_days_slider",
        )
        st.session_state.scenario_state["canary_days"] = int(canary_days)

        weeks_until_customer_season = st.slider(
            "Weeks until assumed customer season",
            min_value=0.0,
            max_value=16.0,
            value=float(st.session_state.scenario_state["weeks_until_customer_season"]),
            step=1.0,
            key="weeks_until_season_slider",
        )
        st.session_state.scenario_state["weeks_until_customer_season"] = weeks_until_customer_season

        support_min_floor = float(st.session_state.scenario_state["support_min_floor_hours"])  # 60 hard synthetic assumption
        st.caption("Minimum support floor (synthetic assumption, hard): 60 hours/week")

        support_hours_req = st.slider(
            "Support hours per week (requested)",
            min_value=0,
            max_value=120,
            value=int(st.session_state.scenario_state["support_hours_per_week_requested"]),
            step=1,
            key="support_hours_req_slider",
        )
        st.session_state.scenario_state["support_hours_per_week_requested"] = float(support_hours_req)

        # First-wave work items selection
        st.markdown("### First-wave work item inclusion")
        # Work items list includes completed+open.
        completed_work_items = [w for w in baseline["work_items"] if w["status"] in ("completed", "open")]
        options = [w["id"] for w in completed_work_items]
        defaults = st.session_state.scenario_state.get("first_wave_work_item_ids", options[:3])
        first_wave = st.multiselect(
            "Select which release work items are included in the first wave",
            options=options,
            default=[x for x in defaults if x in options],
            key="first_wave_multiselect",
        )
        st.session_state.scenario_state["first_wave_work_item_ids"] = first_wave

        st.markdown("### Reset + Snapshot")
        if st.button("Reset to Baseline", key="reset_to_baseline_btn"):
            st.session_state.scenario_state = _scenario_defaults(baseline["work_items"], meta)
            st.session_state.scenario_state["preset_choice"] = "Controlled thin slice"
            st.session_state.scenario_state = _apply_preset_to_state(st.session_state.scenario_state)
            st.rerun()

        snapshot_label = st.text_input("Snapshot label", value="manual_snapshot", key="snapshot_label")
        scenario_id = st.text_input(
            "Scenario ID (for snapshot persistence)",
            value=st.session_state.get("scenario_id", "scn_2026_1105_exec"),
            key="snapshot_scenario_id",
        )
        st.session_state.scenario_id = scenario_id

        if st.button("Save Scenario Snapshot", key="save_scenario_snapshot_btn"):
            snapshot_derived, _snapshot_res = _run_scenario(baseline, st.session_state.scenario_state)
            repository.load_or_create_scenario(
                scenario_id=scenario_id,
                name="Executive simulator scenario",
                description="Saved snapshot from executive simulator.",
                scenario_date=baseline["meta"]["scenario_date"],
                planned_release_date=baseline["meta"]["planned_release_date"],
                seed_baseline_meta_id=baseline["meta"]["id"],
                assumptions_json={"synthetic": True, "notes": "Snapshot stores assumptions and engine outputs."},
            )
            snapshot_id = f"snap_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{scenario_id}"
            repository.save_snapshot(
                scenario_id=scenario_id,
                snapshot_id=snapshot_id,
                snapshot_label=snapshot_label,
                snapshot_json={
                    "timestamp_utc": datetime.utcnow().isoformat(),
                    "decision_rationale": {
                        "preset": st.session_state.scenario_state["preset_choice"],
                        "choice": st.session_state.scenario_state["choice"],
                        "wave_first_items": st.session_state.scenario_state.get("first_wave_work_item_ids", []),
                    },
                    "assumptions": {
                        "synthetic": True,
                        "input_params": {
                            k: v
                            for k, v in st.session_state.scenario_state.items()
                            if k != "first_wave_work_item_ids"
                        },
                        "wave_first_items": st.session_state.scenario_state.get("first_wave_work_item_ids", []),
                    },
                    "outputs": {
                        "deterministic": True,
                        "derived": snapshot_derived,
                        "gate_status": snapshot_derived.get("release_gate_status"),
                    },
                    "labels": {
                        "synthetic_or_unverified_inputs": [
                            "V_per_unit",
                            "value_decay_per_delay_week",
                            "internal_cost_*",
                            "cost_per_*",
                            "Sp_policy_*",
                        ]
                    },
                },
            )
            st.success(f"Saved snapshot {snapshot_id}")

    # Always compute selected scenario from current state (even if view != Recovery Simulator)
    selected_derived, selected_res = _run_scenario(baseline, st.session_state.scenario_state)
    selected_gate = selected_derived["release_gate_status"]

    # Unpack baseline incidents/defects for charts.
    incident_rows = baseline_facts["incident_rows"]
    defect_rows = baseline_facts["defect_rows"]

    # Executive Decision view content
    if view == "Executive Decision":
        st.markdown("## Executive Decision")

        fixed_case = {
            "planned_release_delay_weeks": 4,
            "on_time_completion": baseline_facts["story_completion"]["on_time_rate_display_rounded"],
            "total_completed_percentage": baseline_facts["story_completion"]["completion_total_rate_display_rounded"],
            "incidents_60d": 18,
            "escaped_high_sev_defects": 9,
            "actual_delivery_margin": "14% (fixed)" ,
            "planned_delivery_margin": "20% (fixed)",
        }
        st.subheader("Fixed case facts (immutable)")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Planned delay", f"{fixed_case['planned_release_delay_weeks']} weeks")
        c2.metric("On-time completion", f"{fixed_case['on_time_completion']}%", help="On-time = 11/18 work items")
        c3.metric("Total completed", f"{fixed_case['total_completed_percentage']}%", help="Completed total = 14/18 work items")
        c4.metric("Incidents (60d)", f"{fixed_case['incidents_60d']}", help="Release-related incidents")
        c5, c6 = st.columns(2)
        c5.metric("Escaped defects", f"{fixed_case['escaped_high_sev_defects']}", help="High-severity escaped defects")
        c6.metric("Delivery margin (actual)", fixed_case["actual_delivery_margin"], help="Fixed seed fact")
        st.caption("Fixed case facts come from the synthetic seed data; they are not affected by sliders.")

        st.subheader("Immediate actions and decision requests")
        agent = orchestrator_workflow(
            baseline=baseline,
            sim_result={"derived": selected_derived, "gate_status": selected_gate, "infeasible_for_release": selected_derived["team_allocation"]["service_coverage_breach"]},
            user_notes=None,
        )
        st.caption("Mock/deterministic agent workflow (no model provider calls).")
        blocked = agent["outputs"]["gatekeeper"]["content"]["blocked_reasons"]
        if selected_gate == "PASS" and not selected_derived["team_allocation"]["service_coverage_breach"]:
            blocked = ["Gate status PASS: proceed subject to recorded evidence."]
        st.markdown("**Decision request:**")
        for b in blocked:
            st.write("- " + str(b))

        st.subheader("Next checkpoint")
        next_cp = selected_derived["candidate_readiness_window"]["end_offset_weeks"]
        st.success(
            "Candidate readiness window ends at "
            + _format_checkpoint_weeks(next_cp, max_display=16.0)
            + " (deterministic)."
        )

    # Recovery Simulator view content (controls already shown)
    elif view == "Recovery Simulator":
        st.markdown("## Recovery Simulator")
        st.caption("All recalculations are deterministic from the same selected scenario result.")
        st.markdown("### Selected vs Baseline outcomes")

        col1, col2 = st.columns(2)
        with col1:
            st.metric("Baseline gate status", base_derived["release_gate_status"])
            st.metric("Baseline modeled 90-day margin", f"{base_derived['modeled_90_day_margin']:.1%}")
            st.caption("Baseline is deterministic and derived from fixed seed anchors.")
        with col2:
            st.metric("Selected gate status", selected_gate)
            st.metric("Scenario modeled 90-day margin", f"{selected_derived['modeled_90_day_margin']:.1%}")
            st.caption("Scenario sliders change assumptions only; baseline facts are immutable.")

        st.markdown("### What changed? (plain language)")
        what_changed = []
        for k, label in [
            ("release_gate_status", "Gate status"),
            ("critical_path_weeks", "Critical path"),
            ("unresolved_blocker_count", "Unresolved blockers"),
            ("customer_visible_scope_units", "Customer-visible scope"),
            ("incremental_spend", "Incremental spend"),
            ("modeled_90_day_margin", "Modeled 90-day margin"),
        ]:
            if selected_derived.get(k) != base_derived.get(k):
                what_changed.append(f"{label} changed from {base_derived.get(k)} to {selected_derived.get(k)}")
        for line in what_changed[:10]:
            st.write("- " + line)

        st.markdown("### Timeline (Gantt) — evidence-gated")
        st.altair_chart(_chart_timeline_gantt(selected_derived).properties(height=260), use_container_width=True)
        st.caption("Units: weeks from planning start (t=0).")

    # Release & Defects view content
    elif view == "Release & Defects":
        st.markdown("## Release & Defects")

        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Planned vs actual progress (fixed seed)")
            story = baseline_facts["story_completion"]
            # 61% on-time from 11/18, 78% total completed from 14/18.
            data = [
                {"metric": "On-time completed (fixed)", "value": story["on_time_rate_display_rounded"], "unit": "%"},
                {"metric": "Total completed (fixed)", "value": story["completion_total_rate_display_rounded"], "unit": "%"},
            ]
            chart = alt.Chart(alt.Data(values=data)).mark_bar().encode(
                x=alt.X("metric:N", title=""),
                y=alt.Y("value:Q", title="% of work items"),
                tooltip=[
                    alt.Tooltip("metric:N", title="Metric"),
                    alt.Tooltip("value:Q", title="Value"),
                ],
                color=alt.Color("metric:N"),
            )
            st.altair_chart(chart.properties(height=240), use_container_width=True)
            st.caption("Fixed synthetic seed facts: 61% on-time; 78% total completed.")

        with c2:
            st.subheader("Release gates (deterministic)")
            ta = selected_derived["team_allocation"]
            st.write(f"Gate status: **{selected_gate}**")
            st.write(f"Service coverage breach (support floor): **{ta['service_coverage_breach']}**")
            st.write(f"Critical path (weeks): **{selected_derived['critical_path_weeks']:.2f}**")
            st.write(
                f"Unresolved blockers: **{float(selected_derived['unresolved_blocker_count']):.2f}**"
            )

        st.subheader("Defect status visual (fixed 9 escaped defects)")
        # Baseline defect status distribution (fixed).
        esc = baseline_facts["escaped_defects"]
        status = esc["status_counts"]
        drows = [
            {"status": k.replace("_", " ").title(), "count": v} for k, v in status.items()
        ]
        defect_chart = alt.Chart(alt.Data(values=drows)).mark_arc().encode(
            theta=alt.Theta("count:Q"),
            color=alt.Color("status:N"),
            tooltip=[
                alt.Tooltip("status:N", title="Status"),
                alt.Tooltip("count:Q", title="Count"),
            ],
        )
        st.altair_chart(defect_chart.properties(height=240), use_container_width=True)
        st.caption("Fixed synthetic seed facts: 9 total escaped high-severity defects.")

        st.subheader("Scenario modeled risk signal")
        st.caption("Model output labeled deterministic; not treated as historical facts.")
        st.metric("Scenario unresolved blocker count", selected_derived["unresolved_blocker_count"])

    # Live Service view content
    elif view == "Live Service":
        st.markdown("## Live Service")
        st.caption("60-day incident trend by severity — fixed historical seed facts.")

        scenario_date = meta["scenario_date"]
        # Compute 60-day window start (scenario_date - 60 days).
        import datetime as _dt

        start_dt = _dt.datetime.strptime(scenario_date, "%Y-%m-%d").date() - _dt.timedelta(days=60)
        start_iso = start_dt.strftime("%Y-%m-%d")
        weeks = 10  # 70 days span-ish, deterministic buckets

        sev_buckets = {}
        for sev in ["SEV1", "SEV2", "SEV3"]:
            dates = [r["occurred_at"] for r in incident_rows if r["severity"] == sev]
            sev_buckets[sev] = _bucket_by_weeks(dates, start_iso, weeks)

        # Build data table.
        rows = []
        for w in range(weeks):
            for sev in ["SEV1", "SEV2", "SEV3"]:
                rows.append({"week": w + 1, "severity": sev, "count": sev_buckets[sev][w]})
        df = alt.Data(values=rows)

        incident_trend = (
            alt.Chart(df)
            .mark_line(point=True)
            .encode(
                x=alt.X("week:Q", title="Week bucket (synthetic baseline window)"),
                y=alt.Y("count:Q", title="Incidents"),
                color=alt.Color("severity:N"),
                tooltip=[
                    alt.Tooltip("week:Q", title="Week"),
                    alt.Tooltip("severity:N", title="Severity"),
                    alt.Tooltip("count:Q", title="Incidents"),
                ],
            )
        )
        st.altair_chart(incident_trend.properties(height=260), use_container_width=True)

        st.subheader("Unresolved incidents")
        unresolved = [r for r in incident_rows if r["status"] in ("monitoring", "unresolved")]
        st.write(f"Count: {len(unresolved)}")
        journeys = sorted({r["customer_journey"] for r in unresolved})
        st.write("Affected journeys (unresolved/monitoring): " + ", ".join(journeys) if journeys else "None")

        st.subheader("Support coverage")
        ta = selected_derived["team_allocation"]
        st.write(f"Derived support hours/week: {ta['derived_support_hours_per_week']:.0f}")
        st.write(f"Support floor (hard synthetic): {ta['support_floor_hours_per_week']:.0f}")
        st.write(f"Service coverage breach: {ta['service_coverage_breach']}")

        st.subheader("Stacked capacity (operations / recovery / QA) — deterministic")
        st.altair_chart(_chart_capacity_stacked(selected_derived).properties(height=240), use_container_width=True)

    # Economics & Commitment view content
    elif view == "Economics & Commitment":
        st.markdown("## Economics & Commitment")

        # Margin bridge
        planned = 0.20
        actual = 0.14
        scenario_margin = selected_derived["modeled_90_day_margin"]
        bridge = [
            {"stage": "Planned (fixed)", "value": planned},
            {"stage": "Actual (fixed)", "value": actual},
            {"stage": "Scenario estimate", "value": scenario_margin},
        ]
        chart = alt.Chart(alt.Data(values=bridge)).mark_bar().encode(
            x=alt.X("stage:N", title=""),
            y=alt.Y("value:Q", title="Margin (fraction)", axis=alt.Axis(format=".0%")),
            tooltip=[
                alt.Tooltip("stage:N", title="Stage"),
                alt.Tooltip("value:Q", title="Margin", format=".1%"),
            ],
            color=alt.Color("stage:N"),
        )
        st.altair_chart(chart.properties(height=240), use_container_width=True)
        st.caption("Planned and Actual margins are fixed seed facts. Scenario estimate is deterministic from the engine; economics inputs are synthetic/unverified.")

        mb = selected_derived.get("margin_bridge")
        if mb:
            st.subheader("Recovery-cost bridge (deterministic totals)")
            costs = [
                {"component": "Revenue base", "value": mb["revenue_base" ]},
                {"component": "Execution cost", "value": -mb["cost_execution"]},
                {"component": "Incident cost", "value": -mb["cost_incidents"]},
                {"component": "Escaped defect cost", "value": -mb["cost_escaped_defects"]},
                {"component": "Recovery spend", "value": -mb["cost_recovery"]},
            ]
            # Keep it simple with a stacked bar around the revenue base.
            bridge_chart = alt.Chart(alt.Data(values=costs)).mark_bar().encode(
                x=alt.X("component:N", title=""),
                y=alt.Y("value:Q", title="Currency (synthetic-unverified)")
            )
            st.altair_chart(bridge_chart.properties(height=240), use_container_width=True)
            st.caption("Currency values are derived from labeled synthetic/unverified inputs; not facts." )

        st.subheader("Readiness evidence")
        ms = selected_derived["schedule_milestones"]
        st.write("Candidate readiness ends (weeks): " + f"+{ms['candidate_ready_end_weeks']:.2f}")
        st.write("Evidence minimums included: test+canary (hard), rollback/service/human approval (hard tail)")

        st.subheader("90-day owners (recommended, not facts)")
        owners = [
            {"owner": "Release & Service Gatekeeper", "responsibility": "Non-negotiable gates, evidence recording, rollback/service readiness."},
            {"owner": "Recovery Planner", "responsibility": "Work sequence plan from deterministic evidence and blocker thresholds."},
            {"owner": "Commercial Analyst", "responsibility": "Track recovery spend impact on margin using deterministic outputs."},
            {"owner": "Customer Commitment Drafter", "responsibility": "Conditional customer wording only when authorized by gates."},
        ]
        st.table(owners)

        st.subheader("Commitment gate, evidence, and customer confidence (human-recorded)")

        scenario_id = st.text_input(
            "Scenario ID (for evidence recording)",
            value=st.session_state.get("scenario_id", "scn_2026_1105_exec"),
            key="commitment_scenario_id",
        )
        st.session_state.scenario_id = scenario_id

        # Ensure scenario exists for evidence writes.
        repository.load_or_create_scenario(
            scenario_id=scenario_id,
            name="Executive simulator scenario",
            description="Evidence recorded to support a commitment decision.",
            scenario_date=baseline["meta"]["scenario_date"],
            planned_release_date=baseline["meta"]["planned_release_date"],
            seed_baseline_meta_id=baseline["meta"]["id"],
            assumptions_json={"synthetic": True, "notes": "Scenario assumptions + evidence for commitment gate."},
        )

        db_cfg = DbConfig(db_path=str(DB_PATH))
        with connect(db_cfg) as conn:
            evidence = load_evidence(conn, scenario_id)
            gates = evaluate_commitment_gates(
                baseline_defects=baseline["defects"],
                selected_derived=selected_derived,
                evidence=evidence,
            )
            all_pass = all(g.authorized for g in gates)
            commitment = get_commitment_decision(conn, scenario_id)

        # Gate-by-gate evidence table
        st.markdown("### Gate-by-gate evidence")
        for g in gates:
            status = "PASS" if g.authorized else "MISSING"
            st.write(f"**{g.name}**: {status}")
            if g.missing_items:
                for m in g.missing_items[:8]:
                    st.write("- " + m)
            # Always show the evidence payload in an executive-safe summarized way.
            ev = g.evidence
            if ev:
                st.caption("Evidence recorded: " + str({k: ev[k] for k in list(ev.keys())[:5]}))

        st.markdown("### Candidate commitment window (conditional)")
        cw = selected_derived["candidate_readiness_window"]
        start_weeks = float(cw["start_offset_weeks"])
        end_weeks = float(cw["end_offset_weeks"])
        now = datetime.utcnow()
        candidate_start = now.replace()  # keep UTC now
        candidate_start_date = (now).date().isoformat()
        candidate_end_date = (now).date().isoformat()
        st.write(f"Conditional candidate window (deterministic): +{start_weeks:.2f}w to +{end_weeks:.2f}w")
        st.caption("This date range is conditional until all gates pass and a named human approver marks the commitment decision.")

        st.markdown("### Evidence recorder (human-only; sliders/agents cannot mark verified)")
        recorded_by = st.text_input("Recorded by (human name)", value="", key="evidence_recorded_by")

        if all_pass:
            st.success("All commitment gates pass based on recorded evidence. You may mark commitment with a named approver.")
        else:
            st.warning("Gates are not fully satisfied. Commitment cannot be marked until evidence is recorded.")

        with st.expander("Record defect verification and/or risk acceptance"):
            st.caption("Each verification is human-recorded. Risk acceptance is optional and must name the authorized risk owner.")
            for d in baseline["defects"]:
                d_id = d["id"]
                st.markdown(f"**{d_id}** — release_blocker={bool(d['release_blocker'])}")
                verified_closed = st.checkbox(
                    f"Verified closed for {d_id}",
                    value=False,
                    key=f"verify_{d_id}",
                )
                verifier_name = st.text_input(f"Verifier name for {d_id}", value="", key=f"verifier_{d_id}")
                risk_accept = st.checkbox(
                    f"Risk accepted for {d_id}",
                    value=False,
                    key=f"riskacc_{d_id}",
                )
                risk_owner_name = st.text_input(f"Authorized risk owner for {d_id}", value="", key=f"riskowner_{d_id}")

            if st.button("Save defect evidence", key="save_defect_evidence"):
                if not recorded_by:
                    st.error("Recorded by is required.")
                else:
                    with connect(db_cfg) as conn:
                        from src.data.db import upsert_evidence_defect_verification, upsert_evidence_defect_risk_acceptance

                        now_ts = datetime.utcnow().isoformat()
                        for d in baseline["defects"]:
                            d_id = d["id"]
                            verified_closed = st.session_state.get(f"verify_{d_id}", False)
                            verifier_name = st.session_state.get(f"verifier_{d_id}", "")
                            risk_accept = st.session_state.get(f"riskacc_{d_id}", False)
                            risk_owner_name = st.session_state.get(f"riskowner_{d_id}", "")

                            if verified_closed:
                                if not verifier_name:
                                    st.error(f"Verifier name required for {d_id}")
                                    continue
                                upsert_evidence_defect_verification(
                                    conn,
                                    scenario_id=scenario_id,
                                    defect_id=d_id,
                                    verified_closed=True,
                                    verifier_name=verifier_name,
                                    recorded_at=now_ts,
                                    recorded_by=recorded_by,
                                )
                            if risk_accept:
                                if not risk_owner_name:
                                    st.error(f"Risk owner name required for {d_id}")
                                    continue
                                upsert_evidence_defect_risk_acceptance(
                                    conn,
                                    scenario_id=scenario_id,
                                    defect_id=d_id,
                                    accepted_by=1,
                                    risk_owner_name=risk_owner_name,
                                    recorded_at=now_ts,
                                    recorded_by=recorded_by,
                                )
                    st.success("Defect evidence saved. Re-run gate evaluation.")

        with st.expander("Record regression tests evidence"):
            passed = st.checkbox("Regression tests passed", value=False, key="rt_passed")
            test_run_id = st.text_input("test_run_id", value="", key="rt_runid")
            build_id = st.text_input("build_id", value="", key="rt_buildid")
            if st.button("Save regression tests evidence", key="save_rt"):
                if not recorded_by:
                    st.error("Recorded by is required.")
                else:
                    with connect(db_cfg) as conn:
                        from src.data.db import upsert_evidence_regression_tests

                        upsert_evidence_regression_tests(
                            conn,
                            scenario_id=scenario_id,
                            passed=passed,
                            test_run_id=test_run_id or None,
                            build_id=build_id or None,
                            recorded_at=datetime.utcnow().isoformat(),
                            recorded_by=recorded_by,
                        )
                    st.success("Regression tests evidence saved.")

        with st.expander("Record rollback + monitoring evidence"):
            rollback_tested = st.checkbox("Rollback tested", value=False, key="rb_tested")
            monitoring_available = st.checkbox("Monitoring available", value=False, key="rb_monitoring")
            on_call_owner = st.text_input("on_call_owner", value="", key="rb_oncall")
            if st.button("Save rollback/monitoring evidence", key="save_rb"):
                if not recorded_by:
                    st.error("Recorded by is required.")
                else:
                    with connect(db_cfg) as conn:
                        from src.data.db import upsert_evidence_rollback_monitoring

                        upsert_evidence_rollback_monitoring(
                            conn,
                            scenario_id=scenario_id,
                            rollback_tested=rollback_tested,
                            monitoring_available=monitoring_available,
                            on_call_owner=on_call_owner,
                            recorded_at=datetime.utcnow().isoformat(),
                            recorded_by=recorded_by,
                        )
                    st.success("Rollback/monitoring evidence saved.")

        with st.expander("Record customer acceptance + approvers"):
            customer_accepted = st.checkbox("Customer accepted", value=False, key="ca_accepted")
            account_approver = st.text_input("account_approver", value="", key="ca_account")
            release_approver = st.text_input("release_approver", value="", key="ca_release")
            if st.button("Save customer approvals evidence", key="save_ca"):
                if not recorded_by:
                    st.error("Recorded by is required.")
                else:
                    with connect(db_cfg) as conn:
                        from src.data.db import upsert_evidence_customer_approvals

                        upsert_evidence_customer_approvals(
                            conn,
                            scenario_id=scenario_id,
                            customer_accepted=customer_accepted,
                            account_approver=account_approver or None,
                            release_approver=release_approver or None,
                            recorded_at=datetime.utcnow().isoformat(),
                            recorded_by=recorded_by,
                        )
                    st.success("Customer approvals evidence saved.")

        st.markdown("### Mark commitment decision (human-only)")
        authorized_human_name = st.text_input("Authorized human name", value="", key="commit_authorized_name")
        authorized_human_role = st.text_input("Authorized human role", value="", key="commit_authorized_role")
        if st.button("Mark commitment decision", key="mark_commitment"):
            if not all_pass:
                st.error("Cannot mark commitment: one or more gates are missing evidence.")
            elif not authorized_human_name or not authorized_human_role:
                st.error("Authorized human name and role are required.")
            else:
                with connect(db_cfg) as conn:
                    from src.data.db import upsert_commitment_decision

                    upsert_commitment_decision(
                        conn,
                        scenario_id=scenario_id,
                        authorized_human_name=authorized_human_name,
                        authorized_human_role=authorized_human_role,
                        decision_status="AUTHORIZED",
                        decision_timestamp=datetime.utcnow().isoformat(),
                        candidate_window_start_weeks=start_weeks,
                        candidate_window_end_weeks=end_weeks,
                    )
                st.success("Commitment decision recorded (human authorized).")
                st.rerun()

        # Customer wording
        agent = orchestrator_workflow(
            baseline=baseline,
            sim_result={"derived": selected_derived, "gate_status": selected_gate, "infeasible_for_release": selected_derived["team_allocation"]["service_coverage_breach"]},
            user_notes=None,
        )
        candidate_text = agent["outputs"]["customer_commitment_drafter"]["content"]["draft_text"]

        if commitment and commitment.get("decision_status") == "AUTHORIZED":
            st.success("Commitment decision authorized.")
            st.info(candidate_text + "\n\nCommitted by: " + str(commitment.get("authorized_human_name")) + " at " + str(commitment.get("decision_timestamp")))
        else:
            st.info(candidate_text)
            st.caption("Customer wording is conditional until gates are satisfied and a named human marks commitment.")

        # Exportable briefs
        st.subheader("Exportable decision outputs")
        if "margin_bridge" in selected_derived:
            margin = selected_derived["modeled_90_day_margin"]
        else:
            margin = None
        owners = ["Release & Service Gatekeeper", "Recovery Planner", "Commercial Analyst", "Customer Commitment Drafter"]
        checkpoint = f"+{end_weeks:.2f} weeks candidate readiness window end (deterministic)."
        assumptions = [
            "Economics inputs labeled synthetic/unverified.",
            "Support floor minimum is a synthetic hard constraint (60 hours/week).",
            "Defect/incident totals used by the engine are deterministic arithmetic model outputs, not historical facts.",
        ]

        brief_md = f"""# Application Recovery Decision Brief (Synthetic)

## Scenario
- Scenario ID: {scenario_id}
- Fixed facts: 4 weeks late, 61% on-time completion, 18 incidents/60d, 9 escaped defects (seed facts)

## Recommendation
- Gate status: {selected_gate}
- Service coverage breach: {selected_derived['team_allocation']['service_coverage_breach']}

## Immediate actions
- Evidence recording for each gate listed below
- Execute recovery work sequence based on deterministic critical path milestones

## Decision requests
- Human approvals and recorded evidence (regression run/build IDs, rollback + on-call, customer acceptance)

## Next checkpoint
- {checkpoint}

## Owners
{chr(10).join('- ' + o for o in owners)}

## Measures
- Release gate thresholds (escaped defects, unresolved blockers)
- Critical path feasibility vs planning window
- Modeled margin estimate (scenario) computed by deterministic engine

## Explicit assumptions (unverified)
{chr(10).join('- ' + a for a in assumptions)}
"""

        plan_md = f"""# 90-Day Release, Service & Customer Confidence Plan (Synthetic)

## Summary
- Scenario ID: {scenario_id}
- Planned margin (fixed): 20%
- Actual margin (fixed): 14%
- Scenario modeled margin: {margin}

## Checkpoints (deterministic)
- Candidate readiness window: {checkpoint}

## Service & rollout conditions (human-recorded evidence)
1. Zero unresolved release-blocking Sev1/P1 defects in scope
2. High-severity defects verified closed or explicitly accepted by authorized risk owner
3. Critical regression tests passed with test_run_id and build_id
4. Rollback tested + monitoring available + named on-call owner
5. Live-service conditions and minimum support coverage met
6. Customer acceptance + named account/release approvers recorded

## Owners
{chr(10).join('- ' + o for o in owners)}

## Explicit assumptions
{chr(10).join('- ' + a for a in assumptions)}
"""

        st.download_button(
            "Download Application Recovery Decision Brief (Markdown)",
            data=brief_md,
            file_name=f"decision_brief_{scenario_id}.md",
            mime="text/markdown",
            key="dl_brief",
        )
        st.download_button(
            "Download 90-Day Plan (Markdown)",
            data=plan_md,
            file_name=f"90day_plan_{scenario_id}.md",
            mime="text/markdown",
            key="dl_plan",
        )


if __name__ == "__main__":
    main()
