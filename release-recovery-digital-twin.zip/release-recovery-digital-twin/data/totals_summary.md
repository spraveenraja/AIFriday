# Synthetic Totals Summary (Seed Data)

All totals below are enforced by construction from the synthetic seed data files in this folder.

## Fixed scenario dates
- Scenario date: `2026-11-05`
- Planned release date: `2026-10-08` (exactly 28 days earlier)
- Synthetic high-volume season date: `2026-12-01`

## Release work items (18)
- Completed on time: 11
- Completed late: 3
- Still open: 4
- Total completed: 14
- Displayed on-time completion: 61% (rounded from 11/18 = 61.1%)
- Total completion: 78% (rounded from 14/18 = 77.8%)

## Release-related incidents (18)
- Sev1: 2
- Sev2: 5
- Sev3: 11
- Resolved: 16
- Unresolved or under monitoring: 2
- All incidents have dates within the 60-day window before `2026-11-05`

## Escaped defects (9)
- Status counts:
  - Open: 3
  - In progress: 3
  - Awaiting verification: 2
  - Verified closed: 1
- Release blockers among unresolved defects (8 total unresolved):
  - Blockers: 6
  - Nonblocking: 2

## Capacity allocation (per week)
- 3 shared engineers, each with 40 hours/week
- Baseline split:
  - Support hours/week total: 72
  - Release hours/week total: 48
- QA release hours/week (synthetic assumption): 16

## Synthetic-only assumptions economics
- Monthly contract revenue, recovery-cost range, and service-credit exposure are explicitly **unverified** and marked editable.
