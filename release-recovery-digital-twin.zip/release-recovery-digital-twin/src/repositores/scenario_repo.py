from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from ..data.db import (
    DbConfig,
    baseline_is_seeded,
    connect,
    create_scenario,
    ensure_schema,
    load_baseline,
    load_scenario,
    reset_scenario_data,
    save_scenario_snapshot,
)
from ..data.seed_loader import seed_baseline_from_json_files


@dataclass(frozen=True)
class RepoConfig:
    db_path: str
    seed_data_dir: Path


class ScenarioRepository:
    def __init__(self, cfg: RepoConfig):
        self.cfg = cfg

    def init_db(self, *, reset_scenarios: bool = False) -> Dict[str, Any]:
        """Create schema and seed immutable baseline once.

        Baseline seed is immutable and never overwritten after initial seed.
        Scenario + snapshots are user-editable and can be reset via explicit flag.
        """
        db_cfg = DbConfig(db_path=self.cfg.db_path)
        with connect(db_cfg) as conn:
            ensure_schema(conn)

            if reset_scenarios:
                reset_scenario_data(conn)

            if not baseline_is_seeded(conn):
                seed_baseline_from_json_files(conn, self.cfg.seed_data_dir)

            return load_baseline(conn)

    def load_or_create_scenario(
        self,
        *,
        scenario_id: str,
        name: str,
        description: Optional[str],
        scenario_date: str,
        planned_release_date: str,
        seed_baseline_meta_id: str,
        assumptions_json: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Load scenario if it exists; otherwise create it.

        Critical requirement: do NOT overwrite existing scenario assumptions on app startup.
        """
        db_cfg = DbConfig(db_path=self.cfg.db_path)
        with connect(db_cfg) as conn:
            ensure_schema(conn)

            try:
                return load_scenario(conn, scenario_id)
            except KeyError:
                create_scenario(
                    conn,
                    scenario_id=scenario_id,
                    name=name,
                    description=description,
                    scenario_date=scenario_date,
                    planned_release_date=planned_release_date,
                    seed_baseline_meta_id=seed_baseline_meta_id,
                    assumptions_json=assumptions_json,
                )
                return load_scenario(conn, scenario_id)

    def save_snapshot(
        self,
        *,
        scenario_id: str,
        snapshot_id: str,
        snapshot_label: str,
        snapshot_json: Dict[str, Any],
    ) -> None:
        db_cfg = DbConfig(db_path=self.cfg.db_path)
        with connect(db_cfg) as conn:
            ensure_schema(conn)
            # Transaction boundary for related writes.
            with conn:
                save_scenario_snapshot(
                    conn,
                    snapshot_id=snapshot_id,
                    scenario_id=scenario_id,
                    snapshot_label=snapshot_label,
                    snapshot_json=snapshot_json,
                )
