from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, TypedDict


AgentMode = Literal["mock"]


class StructuredOutput(TypedDict):
    role: str
    output_type: str
    sources: List[str]
    explicit_uncertainty: List[str]
    content: Dict[str, Any]


def _env_provider_configured() -> bool:
    # We intentionally do NOT call any model SDK here.
    # This only detects whether a provider key exists so the UI can show configuration status.
    keys = [
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AZURE_OPENAI_API_KEY",
        "GOOGLE_API_KEY",
    ]
    return any(os.environ.get(k) for k in keys)


def detect_agent_mode() -> AgentMode:
    # Deterministic mock mode only. No model SDK usage.
    return "mock"


def build_evidence_map(baseline: Dict[str, Any], sim_result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "baseline": {
            "scenario_meta": baseline.get("meta", {}),
            "work_items": baseline.get("work_items", []),
            "incidents": baseline.get("incidents", []),
            "escaped_defects": baseline.get("defects", []),
        },
        "simulation": sim_result,
    }


def _source(ref: str) -> str:
    return ref


def recovery_planner_agent(*, evidence: Dict[str, Any]) -> StructuredOutput:
    sim = evidence["simulation"]
    derived = sim["derived"]
    gate = derived["release_gate_status"]
    critical_path = derived["critical_path_weeks"]
    readiness_end = derived["candidate_readiness_window"]["end_offset_weeks"]
    unresolved_blockers = derived["unresolved_blocker_count"]
    team = derived["team_allocation"]

    actions: List[str] = []
    # Deterministic work sequence based on critical path structure.
    actions.append("Allocate support reservation for the entire evidence tail window")
    actions.append("Run development until W_dev completes, then transition to evidence (test + canary)")
    actions.append("During evidence, execute triage backlog until incidents_during_work is fully handled")
    actions.append("After evidence soft window, complete remediation until remediation overflow is zero (or until hard tail evidence finishes)")
    if unresolved_blockers > 0:
        actions.append("Define stop-the-line rule: block release unless blockers fall to configured threshold")

    explicit_uncertainty = [
        "This planner uses deterministic schedule math from the simulation output; it does not model hidden dependencies or human throughput variability beyond inputs.",
        "Any timeline is expressed as a readiness window offset in weeks, not a calendar date.",
    ]

    return {
        "role": "Recovery planner",
        "output_type": "work_sequence_proposal",
        "sources": [
            _source("simulation.derived.release_gate_status"),
            _source("simulation.derived.critical_path_weeks"),
            _source("simulation.derived.candidate_readiness_window.end_offset_weeks"),
            _source("simulation.derived.unresolved_blocker_count"),
            _source("simulation.derived.team_allocation"),
        ],
        "explicit_uncertainty": explicit_uncertainty,
        "content": {
            "gate_status": gate,
            "critical_path_weeks": critical_path,
            "candidate_readiness_window_end_offset_weeks": readiness_end,
            "proposed_sequence": actions,
            "team_allocation_snapshot": team,
        },
    }


def release_and_service_gatekeeper_agent(*, evidence: Dict[str, Any]) -> StructuredOutput:
    sim = evidence["simulation"]
    derived = sim["derived"]
    gate_status = derived["release_gate_status"]
    infeasible = sim.get("infeasible_for_release", False)

    blocked_reasons: List[str] = []
    if infeasible:
        blocked_reasons.append("Infeasible: derived support reservation would fall below the configured floor.")
    if gate_status != "PASS":
        if gate_status == "FAIL_TIME":
            blocked_reasons.append("Evidence readiness window failed the planning window time gate.")
        elif gate_status == "FAIL_DEFECTS":
            blocked_reasons.append("Escaped defect threshold gate failed.")
        elif gate_status == "FAIL_BLOCKERS":
            blocked_reasons.append("Unresolved blocker threshold gate failed.")

    return {
        "role": "Release and service gatekeeper",
        "output_type": "release_authorization_check",
        "sources": [
            _source("simulation.gate_status"),
            _source("simulation.infeasible_for_release"),
            _source("simulation.derived.critical_path_weeks"),
            _source("simulation.derived.unresolved_blocker_count"),
        ],
        "explicit_uncertainty": [
            "This gatekeeper only evaluates gates computed by deterministic simulation output; it does not verify external operational readiness beyond recorded inputs.",
        ],
        "content": {
            "authorized": gate_status == "PASS" and not infeasible,
            "gate_status": gate_status,
            "blocked_reasons": blocked_reasons,
            "non_weakenable_evidence": [
                "rollback/service/human approval evidence minimums are included in the critical path calculation",
            ],
        },
    }


def commercial_analyst_agent(*, evidence: Dict[str, Any]) -> StructuredOutput:
    derived = evidence["simulation"]["derived"]
    # Must not recalculate costs or margin.
    margin = derived["modeled_90_day_margin"]
    incremental_spend = derived["incremental_spend"]
    spend_components = derived["incremental_spend_components"]

    return {
        "role": "Commercial analyst",
        "output_type": "cost_and_margin_explanation",
        "sources": [
            _source("simulation.derived.modeled_90_day_margin"),
            _source("simulation.derived.incremental_spend"),
            _source("simulation.derived.incremental_spend_components"),
        ],
        "explicit_uncertainty": [
            "All economics inputs used by the code are labeled synthetic/unverified. This explanation repeats the already computed outputs without recomputing financial values.",
        ],
        "content": {
            "modeled_90_day_margin": margin,
            "incremental_spend": incremental_spend,
            "incremental_spend_components": spend_components,
            "notes": "No financial arithmetic is performed here; values are copied from simulation output.",
        },
    }


def customer_commitment_drafter_agent(*, evidence: Dict[str, Any]) -> StructuredOutput:
    sim = evidence["simulation"]
    derived = sim["derived"]
    authorized = derived["release_gate_status"] == "PASS" and not sim.get("infeasible_for_release", False)
    readiness_end = derived["candidate_readiness_window"]["end_offset_weeks"]
    unresolved_blockers = derived["unresolved_blocker_count"]

    # Must not set committed date. Must be conditional and evidence-based.
    if authorized:
        wording = (
            "We are on track to proceed with the release only after completing the required test/canary evidence and the rollback/service/human approval evidence.")
        wording += (
            f" The model indicates a candidate readiness window ending at +{readiness_end:.2f} weeks, with unresolved blockers expected to be within the configured thresholds."
            f" Current modeled unresolved blockers: {unresolved_blockers}."
        )
        wording += " Final scheduling remains subject to recorded evidence and approvals."
    else:
        wording = (
            "We are not planning to proceed with this release in the current window because the deterministic model indicates one or more non-negotiable release gates have not been satisfied."
            " We will re-evaluate after the required evidence and blocker thresholds can be met."
        )
        wording += f" Modeled unresolved blockers: {unresolved_blockers}."

    return {
        "role": "Customer commitment drafter",
        "output_type": "conditional_customer_wording",
        "sources": [
            _source("simulation.derived.release_gate_status"),
            _source("simulation.derived.candidate_readiness_window.end_offset_weeks"),
            _source("simulation.derived.unresolved_blocker_count"),
        ],
        "explicit_uncertainty": [
            "This drafting is conditional and does not set a committed date. It is based only on deterministic simulation outputs and does not account for operational events not included in recorded evidence.",
        ],
        "content": {
            "authorized_to_proceed_per_model": authorized,
            "draft_text": wording,
            "approval_required": [
                "Human approvals and recorded evidence must be completed prior to any customer-facing commitment.",
            ],
            "no_committed_date": True,
        },
    }


def orchestrator_workflow(*, baseline: Dict[str, Any], sim_result: Dict[str, Any], user_notes: Optional[str] = None) -> Dict[str, Any]:
    """Bounded agent workflow.

    Security constraints (enforced by implementation):
    - Agents do not persist changes; they return structured suggestions only.
    - Agents do not bypass gates; gatekeeper uses computed gate status.
    - Agents do not set committed dates or send customer communications.
    - user_notes is treated as untrusted input and is never used as evidence.
    """
    _ = user_notes  # untrusted; not used in reasoning

    evidence = build_evidence_map(baseline, sim_result)
    return {
        "mode": detect_agent_mode(),
        "provider_configured": _env_provider_configured(),
        "outputs": {
            "recovery_planner": recovery_planner_agent(evidence=evidence),
            "gatekeeper": release_and_service_gatekeeper_agent(evidence=evidence),
            "commercial_analyst": commercial_analyst_agent(evidence=evidence),
            "customer_commitment_drafter": customer_commitment_drafter_agent(evidence=evidence),
        },
        "security": {
            "notes": "Agents are mock/deterministic. No model keys are used. No side effects are performed.",
            "untrusted_user_input_treatment": "user_notes is ignored as evidence.",
            "no_production_changes": True,
            "no_historical_mutation": True,
            "no_customer_communication_sent": True,
        },
    }
