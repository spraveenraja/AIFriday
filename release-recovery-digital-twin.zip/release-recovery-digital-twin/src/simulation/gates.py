from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def load_evidence(conn: sqlite3.Connection, scenario_id: str) -> Dict[str, Any]:
    evidence: Dict[str, Any] = {}
    evidence["defect_verifications"] = [
        _row_to_dict(r)
        for r in conn.execute(
            "SELECT * FROM evidence_defect_verification WHERE scenario_id = ?", (scenario_id,)
        ).fetchall()
    ]
    evidence["defect_risk_acceptances"] = [
        _row_to_dict(r)
        for r in conn.execute(
            "SELECT * FROM evidence_defect_risk_acceptance WHERE scenario_id = ?", (scenario_id,)
        ).fetchall()
    ]
    evidence["regression_tests"] = conn.execute(
        "SELECT * FROM evidence_regression_tests WHERE scenario_id = ?", (scenario_id,)
    ).fetchone()
    evidence["rollback_monitoring"] = conn.execute(
        "SELECT * FROM evidence_rollback_monitoring WHERE scenario_id = ?", (scenario_id,)
    ).fetchone()
    evidence["customer_approvals"] = conn.execute(
        "SELECT * FROM evidence_customer_approvals WHERE scenario_id = ?", (scenario_id,)
    ).fetchone()

    if evidence["regression_tests"] is not None:
        evidence["regression_tests"] = _row_to_dict(evidence["regression_tests"])
    if evidence["rollback_monitoring"] is not None:
        evidence["rollback_monitoring"] = _row_to_dict(evidence["rollback_monitoring"])
    if evidence["customer_approvals"] is not None:
        evidence["customer_approvals"] = _row_to_dict(evidence["customer_approvals"])
    return evidence


@dataclass(frozen=True)
class GateCheck:
    name: str
    authorized: bool
    missing_items: List[str]
    evidence: Dict[str, Any]


def evaluate_commitment_gates(
    *,
    baseline_defects: List[Dict[str, Any]],
    selected_derived: Dict[str, Any],
    evidence: Dict[str, Any],
) -> List[GateCheck]:
    """Evaluate gate-by-gate commitment eligibility.

    This function is deterministic: it only uses deterministic engine output + stored
    evidence tables. Sliders/agents must not mark evidence verified; they only trigger UI.
    """

    # Interpret "Sev1/P1 release-blocking" as release_blocker==1 and severity==HIGH for this seeded model.
    in_scope_release_blocking_defects = [
        d
        for d in baseline_defects
        if int(d.get("release_blocker", 0)) == 1 and d.get("severity") == "HIGH"
    ]
    in_scope_high_sev_defects = [
        d
        for d in baseline_defects
        if d.get("severity") == "HIGH"
    ]

    # Index evidence
    ver_by_defect = {e["defect_id"]: e for e in evidence["defect_verifications"]}
    risk_acc_by_defect = {e["defect_id"]: e for e in evidence["defect_risk_acceptances"] if int(e.get("accepted_by", 0)) == 1}

    # Gate 1: zero unresolved release-blocking Sev1/P1 defects
    missing_1: List[str] = []
    unresolved_blocking = []
    for d in in_scope_release_blocking_defects:
        defect_id = d["id"]
        ver = ver_by_defect.get(defect_id)
        risk = risk_acc_by_defect.get(defect_id)
        verified = bool(ver and int(ver.get("verified_closed", 0)) == 1)
        accepted = bool(risk)
        if not verified and not accepted:
            unresolved_blocking.append(defect_id)
            missing_1.append(f"Release-blocking defect {defect_id} not verified closed and not risk-accepted")

    gate1_ok = len(unresolved_blocking) == 0
    gate1 = GateCheck(
        name="Zero unresolved release-blocking Sev1/P1 defects",
        authorized=gate1_ok,
        missing_items=missing_1,
        evidence={"unresolved_release_blocking_defects": unresolved_blocking},
    )

    # Gate 2: high-severity in-scope defects fixed + verified OR accepted
    missing_2: List[str] = []
    unresolved_high = []
    for d in in_scope_high_sev_defects:
        defect_id = d["id"]
        ver = ver_by_defect.get(defect_id)
        risk = risk_acc_by_defect.get(defect_id)
        verified = bool(ver and int(ver.get("verified_closed", 0)) == 1)
        accepted = bool(risk)
        if not verified and not accepted:
            unresolved_high.append(defect_id)
            missing_2.append(f"High-severity defect {defect_id} missing verification or risk acceptance")
    gate2_ok = len(unresolved_high) == 0
    gate2 = GateCheck(
        name="High-severity in-scope defects verified or risk accepted",
        authorized=gate2_ok,
        missing_items=missing_2,
        evidence={"unresolved_high_severity_defects": unresolved_high},
    )

    # Gate 3: critical regression tests passed with run/build identifiers
    rt = evidence.get("regression_tests")
    missing_3: List[str] = []
    if not rt:
        gate3_ok = False
        missing_3.append("Regression tests evidence not recorded")
    else:
        gate3_ok = int(rt.get("passed", 0)) == 1
        if not gate3_ok:
            missing_3.append("Regression tests did not pass")
        if not rt.get("test_run_id"):
            missing_3.append("Missing test_run_id")
        if not rt.get("build_id"):
            missing_3.append("Missing build_id")
    gate3 = GateCheck(
        name="Critical regression tests passed (with run/build IDs)",
        authorized=gate3_ok,
        missing_items=missing_3,
        evidence=rt or {},
    )

    # Gate 4: rollback tested, monitoring available, on-call owner confirmed
    rb = evidence.get("rollback_monitoring")
    missing_4: List[str] = []
    if not rb:
        gate4_ok = False
        missing_4.append("Rollback/monitoring evidence not recorded")
    else:
        gate4_ok = (int(rb.get("rollback_tested", 0)) == 1) and (int(rb.get("monitoring_available", 0)) == 1)
        if not int(rb.get("rollback_tested", 0)) == 1:
            missing_4.append("Rollback not tested")
        if not int(rb.get("monitoring_available", 0)) == 1:
            missing_4.append("Monitoring not available")
        if not rb.get("on_call_owner"):
            missing_4.append("Missing on_call_owner")
    gate4 = GateCheck(
        name="Rollback tested + monitoring available + named on-call owner",
        authorized=gate4_ok,
        missing_items=missing_4,
        evidence=rb or {},
    )

    # Gate 5: live-service conditions and minimum support coverage
    ta = selected_derived.get("team_allocation", {})
    breach = bool(ta.get("service_coverage_breach", False))
    missing_5: List[str] = []
    gate5_ok = not breach
    if breach:
        missing_5.append("Service coverage breach: support floor not met")
    gate5 = GateCheck(
        name="Live-service conditions + minimum support coverage met",
        authorized=gate5_ok,
        missing_items=missing_5,
        evidence={"service_coverage_breach": breach, "team_allocation": ta},
    )

    # Gate 6: customer acceptance + named account/release approvers recorded
    ca = evidence.get("customer_approvals")
    missing_6: List[str] = []
    if not ca:
        gate6_ok = False
        missing_6.append("Customer approvals evidence not recorded")
    else:
        gate6_ok = int(ca.get("customer_accepted", 0)) == 1
        if not gate6_ok:
            missing_6.append("Customer acceptance not recorded as accepted")
        if not ca.get("account_approver"):
            missing_6.append("Missing account_approver")
        if not ca.get("release_approver"):
            missing_6.append("Missing release_approver")
    gate6 = GateCheck(
        name="Customer acceptance + account/release approvers recorded",
        authorized=gate6_ok,
        missing_items=missing_6,
        evidence=ca or {},
    )

    return [gate1, gate2, gate3, gate4, gate5, gate6]
