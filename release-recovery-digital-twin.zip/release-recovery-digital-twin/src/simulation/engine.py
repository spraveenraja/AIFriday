from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple


ReleaseChoice = Literal["CTS", "FRZ", "BRS", "ALL"]
GateStatus = Literal["PASS", "FAIL_TIME", "FAIL_DEFECTS", "FAIL_BLOCKERS"]


def clamp(x: float, lo: float, hi: float) -> float:
    return min(hi, max(lo, x))


def ceil_int(x: float) -> int:
    import math

    return int(math.ceil(x))


def floor_int(x: float) -> int:
    import math

    return int(math.floor(x))


def parse_choice_scope_fraction(choice: ReleaseChoice, params: Dict[str, Any]) -> float:
    # Per prompt: CTS has a thin-slice slider input.
    if choice == "CTS":
        f = float(params["cts_scope_fraction"])
        if not (0 < f <= 1):
            raise ValueError("cts_scope_fraction must be in (0,1]")
        return f
    if choice == "FRZ":
        return 0.0
    if choice in ("BRS", "ALL"):
        return 1.0
    raise ValueError(f"Unknown choice: {choice}")


def compute_story_completion(work_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    completed = [w for w in work_items if w["status"] == "completed"]
    open_items = [w for w in work_items if w["status"] == "open"]

    completed_count = len(completed)
    on_time_count = sum(1 for w in completed if w.get("completed_on_time") == 1)
    late_count = completed_count - on_time_count
    open_count = len(open_items)
    total = len(work_items)

    # Display rates per prompt.
    on_time_rate = on_time_count / total if total else 0.0
    completion_total_rate = completed_count / total if total else 0.0
    return {
        "total_work_items": total,
        "completed_count": completed_count,
        "completed_on_time_count": on_time_count,
        "completed_late_count": late_count,
        "open_count": open_count,
        "on_time_rate": on_time_rate,
        "completion_total_rate": completion_total_rate,
        "on_time_rate_display_rounded": int(round(on_time_rate * 100)),
        "completion_total_rate_display_rounded": int(round(completion_total_rate * 100)),
    }


def compute_incident_totals(incidents: List[Dict[str, Any]]) -> Dict[str, Any]:
    by_sev = {"SEV1": 0, "SEV2": 0, "SEV3": 0}
    resolved = 0
    unresolved = 0
    for inc in incidents:
        sev = inc["severity"]
        if sev in by_sev:
            by_sev[sev] += 1
        status = inc["status"]
        if status in ("resolved", "monitoring"):
            # Prompt says: 16 resolved and 2 unresolved or under monitoring.
            # Treat only "resolved" as resolved; "monitoring" as unresolved/under-monitoring.
            if status == "resolved":
                resolved += 1
            else:
                unresolved += 1
        else:
            unresolved += 1
    return {
        "total_incidents": len(incidents),
        "sevcnt": by_sev,
        "resolved_count": resolved,
        "unresolved_or_monitoring_count": unresolved,
    }


def compute_escaped_defects(defects: List[Dict[str, Any]]) -> Dict[str, Any]:
    # Prompt-defined statuses.
    status_counts = {
        "open": 0,
        "in_progress": 0,
        "awaiting_verification": 0,
        "verified_closed": 0,
    }
    release_blocker_unresolved = 0
    release_blocker_total_unresolved = 0
    unresolved_total = 0
    for d in defects:
        st = d["status"]
        if st in status_counts:
            status_counts[st] += 1
        if st != "verified_closed":
            unresolved_total += 1
            if int(d["release_blocker"]) == 1:
                release_blocker_unresolved += 1
    release_blockers_among_unresolved = release_blocker_unresolved
    nonblocking = unresolved_total - release_blockers_among_unresolved
    return {
        "total_escaped_defects": len(defects),
        "status_counts": status_counts,
        "unresolved_defects_count": unresolved_total,
        "release_blockers_among_unresolved": release_blockers_among_unresolved,
        "nonblocking_among_unresolved": nonblocking,
    }


def compute_capacity(capacity_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    # Prompt: 3 shared engineers at 40 hours each per week. Baseline totals:
    # support hours per week = 72, release hours per week = 48.
    total_support = sum(float(r["support_hours_per_week"]) for r in capacity_rows)
    total_release = sum(float(r["release_hours_per_week"]) for r in capacity_rows)
    total_hours = sum(float(r["total_hours_per_week"]) for r in capacity_rows)
    engineer_count = len(capacity_rows)
    return {
        "engineer_count": engineer_count,
        "total_support_hours_per_week": total_support,
        "total_release_hours_per_week": total_release,
        "total_engineer_hours_per_week": total_hours,
    }


@dataclass(frozen=True)
class SimulationResult:
    choice: ReleaseChoice
    infeasible_for_release: bool
    gate_status: GateStatus
    derived: Dict[str, Any]


def simulate_release_recovery(
    *,
    baseline: Dict[str, Any],
    choice: ReleaseChoice,
    params: Dict[str, Any],
) -> SimulationResult:
    """Deterministic simulation.

    The simulator calculates schedule/capacity, defects, blockers, spend, and margin using
    only explicit arithmetic.

    It does not overwrite baseline facts. It treats any economics/service-credit numbers as
    synthetic/unverified assumptions passed via `params`.
    """

    work_items = baseline["work_items"]
    incidents = baseline["incidents"]
    defects = baseline["defects"]
    capacity_rows = baseline["capacity"]
    meta = baseline["meta"]

    # Validate units and required inputs.
    required = [
        "engineering_hours_per_week",
        "support_hours_per_week",
        "support_min_floor",
        "specialist_engineers_shared_with_support",
        "borrowed_specialists_hours_per_week",
        "borrowed_specialists_cost_per_hour",
        "qa_hours_per_week",
        "defect_remediation_effort",
        "test_duration",
        "canary_duration",
        "rollback_duration",
        "service_duration",
        "human_approval_duration",
        "planning_window_end_offset_weeks",
        "recovery_spend_cap",
        "cts_scope_fraction",
        # gate thresholds
        "max_escaped_high_sev_allowed",
        "max_unresolved_blockers_allowed",
        "weeks_until_customer_season",
    ]
    for k in required:
        if k not in params:
            raise ValueError(f"Missing required param: {k}")

    H_eng = float(params["engineering_hours_per_week"])
    H_sup_req = float(params["support_hours_per_week"])
    H_sup_floor = float(params["support_min_floor"])
    N_shared = int(params["specialist_engineers_shared_with_support"])
    H_borrow = float(params["borrowed_specialists_hours_per_week"])
    C_borrow = float(params["borrowed_specialists_cost_per_hour"])
    H_qa = float(params["qa_hours_per_week"])
    R_def = float(params["defect_remediation_effort"])
    T_test = float(params["test_duration"])
    T_canary = float(params["canary_duration"])
    T_rb = float(params["rollback_duration"])
    T_service = float(params["service_duration"])
    T_approval = float(params["human_approval_duration"])
    W_plan_end = float(params["planning_window_end_offset_weeks"])
    Sp_cap = float(params["recovery_spend_cap"])
    max_escaped_allowed = int(params["max_escaped_high_sev_allowed"])
    max_blockers_allowed = int(params["max_unresolved_blockers_allowed"])
    weeks_until_customer_season = float(params["weeks_until_customer_season"])

    if H_eng <= 0:
        raise ValueError("engineering_hours_per_week must be > 0")
    if H_sup_req < 0 or H_sup_floor < 0:
        raise ValueError("support hours must be >= 0")
    if H_borrow < 0 or C_borrow < 0:
        raise ValueError("borrowed specialist hours/cost must be >= 0")
    if H_qa <= 0:
        raise ValueError("qa_hours_per_week must be > 0")
    if R_def <= 0:
        raise ValueError("defect_remediation_effort must be > 0")
    if any(x < 0 for x in (T_rb, T_service, T_approval)):
        raise ValueError("evidence tails must be >= 0")

    # Baseline capacity records are used for deriving the support floor relationship.
    cap = compute_capacity(capacity_rows)
    total_engineers_hours = cap["total_engineer_hours_per_week"]
    if total_engineers_hours != 120:
        # Hard constraint from the prompt.
        raise ValueError(f"Expected 120 total engineer hours/week, got {total_engineers_hours}")

    # Capacity model requirement:
    # - Three engineers provide 120 total hours/week.
    # - At baseline of 48 recovery hours, derive 72 support hours.
    # - If recovery hours reduce support below configured floor, mark infeasible.
    #
    # Here we interpret `support_hours_per_week` as configured support reservation under this scenario.
    # We must also ensure baseline mapping is respected.
    #
    # Let support hours (under recovery load) = total_hours - recovery_hours.
    # Recovery hours in this model are the portion of hours that are not support.
    recovery_hours_baseline = float(params.get("baseline_recovery_hours_per_week", 48.0))
    derived_support_baseline = total_engineers_hours - recovery_hours_baseline
    if abs(derived_support_baseline - 72.0) > 1e-6:
        raise ValueError("Baseline mapping (120 total, 48 recovery => 72 support) violated")

    recovery_hours_effective = float(params.get("recovery_hours_per_week", H_eng))
    derived_support_effective = total_engineers_hours - recovery_hours_effective
    infeasible = derived_support_effective < H_sup_floor

    # Scope and decision mapping.
    scope_fraction = parse_choice_scope_fraction(choice, params)
    H_borrow_eff = H_borrow if choice == "BRS" else 0.0

    # Specialist sharing loss: deterministic capacity reduction.
    # Need model assumption: hours/week per specialist in baseline accounting.
    H_specialist_baseline_per_engineer = float(params.get("H_specialist_baseline_per_engineer", 16.0))
    k_support_sharing_loss = min(1.0, (N_shared * H_specialist_baseline_per_engineer) / max(H_eng, 1e-9))

    # Do not silently clamp support reservation. If support falls below the configured floor,
    # the scenario is already marked infeasible for release (service coverage breach).
    # We still use the un-clamped requested support value in deterministic schedule math.
    H_sup_eff = H_sup_req
    H_eng_avail = max(0.0, H_eng - H_sup_eff)
    H_eng_delivery = H_eng_avail * (1.0 - k_support_sharing_loss)
    H_eng_total = H_eng_delivery + H_borrow_eff

    # Timeline / schedule model (deterministic).
    U_scope = float(params.get("scope_remaining_units", 1.0))
    U_deps = float(params.get("dependency_units", 0.0))
    f_deps_overhead = float(params.get("dependency_overhead_fraction", 0.0))
    f_deps_exposed = float(params.get("dependency_exposure_fraction", 0.0))

    effort_hours_per_scope_unit = float(params.get("effort_hours_per_scope_unit", 40.0))
    effort_hours_per_dependency_unit = float(params.get("effort_hours_per_dependency_unit", 10.0))

    f_deps_overhead_used = f_deps_overhead
    U_deps_exposed = U_deps * f_deps_exposed * scope_fraction

    U_scope_attempted = U_scope * scope_fraction
    feature_effort_hours = U_scope_attempted * effort_hours_per_scope_unit * (1.0 + f_deps_overhead_used)
    dependency_effort_hours = U_deps_exposed * effort_hours_per_dependency_unit

    W_dev = (feature_effort_hours + dependency_effort_hours) / max(H_eng_total, 1e-9)

    # Evidence minimums (hard minima; invariant to scope slider):
    W_evidence_soft = T_test + T_canary

    # Incident exposure window uses W_dev + W_evidence_soft.
    lambda_inc_day = float(params.get("incident_rate_per_day", (18.0 / 60.0)))
    incidents_during_work = ceil_int(lambda_inc_day * 7.0 * (W_dev + W_evidence_soft))

    triage_hours_per_incident = float(params.get("triage_hours_per_incident", 2.0))
    triage_hours = incidents_during_work * triage_hours_per_incident
    W_triage = triage_hours / max(H_eng_total, 1e-9)

    # Defects introduction + escape (deterministic).
    K_defects_intro_full = float(params.get("K_defects_intro_full", 9.0))
    k_incident_pressure = float(params.get("k_incident_pressure", 0.2))
    I_base_equiv = float(params.get("incidents_baseline_equiv", 18.0))
    escape_fraction_baseline = float(params.get("escape_fraction_baseline", 0.2))

    qa_detection_coverage_per_qa_hour = float(params.get("qa_detection_coverage_per_qa_hour", 0.0005))
    escape_reduction_cap_from_qa = float(params.get("escape_reduction_cap_from_qa", 0.5))

    # Recovery spend.
    Sp_policy_map = {
        "CTS": float(params.get("Sp_policy_CTS", 0.7)),
        "FRZ": float(params.get("Sp_policy_FRZ", 0.4)),
        "BRS": float(params.get("Sp_policy_BRS", 0.5)),
        "ALL": float(params.get("Sp_policy_ALL", 0.2)),
    }
    recovery_spend_applied = min(Sp_cap, Sp_policy_map[choice] * Sp_cap)

    alpha_escape = float(params.get("recovery_spend_to_escape_reduction", 0.00002))
    escape_reduction_from_spend = alpha_escape * recovery_spend_applied

    defects_introduced = K_defects_intro_full * scope_fraction * (1.0 + k_incident_pressure * (incidents_during_work / max(I_base_equiv, 1e-9)))

    qa_coverage = H_qa * qa_detection_coverage_per_qa_hour * W_evidence_soft
    escape_reduction_from_qa = min(escape_reduction_cap_from_qa, qa_coverage / max(defects_introduced, 1.0))

    escape_fraction_effective = clamp(escape_fraction_baseline - escape_reduction_from_qa - escape_reduction_from_spend, 0.0, 1.0)

    remediable_defects = defects_introduced * (1.0 - escape_fraction_effective)
    remediation_hours_required = remediable_defects * R_def
    remediation_hours_capacity = H_eng_total * W_evidence_soft
    remediation_overflow_hours = max(0.0, remediation_hours_required - remediation_hours_capacity)
    W_remediation_overflow = remediation_overflow_hours / max(H_eng_total, 1e-9)

    escaped_defects_after_capacity = defects_introduced * escape_fraction_effective
    escaped_defects_overflow = ceil_int(remediation_overflow_hours / R_def)
    escaped_high_sev_defects_modeled = ceil_int(escaped_defects_after_capacity) + escaped_defects_overflow

    # Blockers
    blockers_per_incident = float(params.get("blockers_per_incident", 1.0))
    blockers_from_incidents = ceil_int(blockers_per_incident * incidents_during_work)
    blockers_from_escaped_defects = escaped_high_sev_defects_modeled
    alpha_blocker = float(params.get("recovery_spend_to_blocker_reduction", 0.00005))
    blockers_reduction_from_spend = floor_int(alpha_blocker * recovery_spend_applied)
    unresolved_blocker_count = max(0, blockers_from_incidents + blockers_from_escaped_defects - blockers_reduction_from_spend)

    # Critical path / readiness window
    W_hard_tail = T_rb + T_service + T_approval
    critical_path_weeks = W_dev + W_evidence_soft + W_triage + W_remediation_overflow + W_hard_tail
    time_gate_pass = critical_path_weeks <= W_plan_end
    defect_gate_pass = escaped_high_sev_defects_modeled <= max_escaped_allowed
    blocker_gate_pass = unresolved_blocker_count <= max_blockers_allowed

    if infeasible:
        gate_status: GateStatus = "FAIL_TIME"
    elif time_gate_pass and defect_gate_pass and blocker_gate_pass:
        gate_status = "PASS"
    elif not time_gate_pass:
        gate_status = "FAIL_TIME"
    elif not defect_gate_pass:
        gate_status = "FAIL_DEFECTS"
    else:
        gate_status = "FAIL_BLOCKERS"

    candidate_readiness_window = {"start_offset_weeks": 0.0, "end_offset_weeks": critical_path_weeks}

    # Customer-visible scope
    customer_visible_scope_units = U_scope * scope_fraction if gate_status == "PASS" else 0.0

    # Incremental spend
    incremental_recovery_spend = recovery_spend_applied
    incremental_borrowed_spend = (H_borrow_eff * C_borrow * W_dev) if choice == "BRS" else 0.0
    incremental_spend = incremental_recovery_spend + incremental_borrowed_spend

    # 90-day margin: uses labeled synthetic assumptions.
    V_per_unit = float(params.get("V_per_unit", 1_000_000.0))
    value_decay_per_delay_week = float(params.get("value_decay_per_delay_week", 0.04))
    internal_cost_engineering_per_hour = float(params.get("internal_cost_engineering_per_hour", 150.0))
    internal_cost_qa_per_hour = float(params.get("internal_cost_qa_per_hour", 120.0))
    cost_per_incident = float(params.get("cost_per_incident", 50_000.0))
    cost_per_escaped_high_sev_defect = float(params.get("cost_per_escaped_high_sev_defect", 120_000.0))
    delay_penalty_weeks_on_failure = float(params.get("delay_penalty_weeks_on_failure", 8.0))

    ship_delay_weeks_from_now = critical_path_weeks if gate_status == "PASS" else critical_path_weeks + delay_penalty_weeks_on_failure

    # Season-based decay (deterministic): value decays relative to the assumed customer season.
    # delay_after_season_weeks = max(0, ship_delay_weeks_from_now - weeks_until_customer_season)
    delay_after_season_weeks = max(0.0, ship_delay_weeks_from_now - weeks_until_customer_season)
    value_base = customer_visible_scope_units * V_per_unit
    value_decay_multiplier = clamp(1.0 - value_decay_per_delay_week * delay_after_season_weeks, 0.0, 1.0)
    value_delivered = value_base * value_decay_multiplier

    execution_hours = (W_dev + W_evidence_soft) * H_eng_total + W_evidence_soft * H_qa
    weighted_internal_cost_per_hour = (
        (H_eng_total * internal_cost_engineering_per_hour + H_qa * internal_cost_qa_per_hour)
        / max(H_eng_total + H_qa, 1e-9)
    )
    execution_cost = execution_hours * weighted_internal_cost_per_hour
    incident_cost = incidents_during_work * cost_per_incident
    escaped_defect_cost = escaped_high_sev_defects_modeled * cost_per_escaped_high_sev_defect
    recovery_cost = incremental_spend
    total_cost = execution_cost + incident_cost + escaped_defect_cost + recovery_cost

    modeled_90_day_margin = ((value_delivered - total_cost) / value_base) if value_base > 0 else 0.0
    modeled_90_day_margin = clamp(modeled_90_day_margin, -1.0, 1.0)

    # Deterministic derived outputs that the prompt lists.
    # Additional intermediate fields are included to support executive charts.
    # These are still derived purely from deterministic arithmetic above.
    revenue_base = value_base
    value_delivered_total = value_delivered
    total_cost_value = total_cost

    operations_engineering_hours = W_dev * H_eng_delivery
    recovery_engineering_hours = (W_evidence_soft + W_triage + W_remediation_overflow) * H_eng_delivery
    qa_hours_total = W_evidence_soft * H_qa

    result_derived = {
        "candidate_readiness_window": candidate_readiness_window,
        "critical_path_weeks": critical_path_weeks,
        "schedule_milestones": {
            "W_dev": W_dev,
            "W_evidence_soft": W_evidence_soft,
            "W_triage": W_triage,
            "W_remediation_overflow": W_remediation_overflow,
            "W_hard_tail": W_hard_tail,
            "candidate_ready_end_weeks": critical_path_weeks,
        },
        "release_gate_status": gate_status,
        "team_allocation": {
            "support_hours_per_week_effective": H_sup_eff,
            "derived_support_hours_per_week": derived_support_effective,
            "support_floor_hours_per_week": H_sup_floor,
            "service_coverage_breach": infeasible,
            "engineering_delivery_hours_per_week": H_eng_delivery,
            "borrowed_specialists_hours_per_week_effective": H_borrow_eff,
            "engineering_total_hours_per_week": H_eng_total,
            "qa_hours_per_week": H_qa,
        },
        "hourly_capacity_breakdown": {
            "operations_engineering_hours_total": operations_engineering_hours,
            "recovery_engineering_hours_total": recovery_engineering_hours,
            "qa_hours_total": qa_hours_total,
        },
        "modeling": {
            "incidents_during_work": incidents_during_work,
            "triage_hours": triage_hours,
            "defects_introduced": defects_introduced,
            "escape_fraction_effective": escape_fraction_effective,
            "remediation_overflow_hours": remediation_overflow_hours,
            "escaped_defects_after_capacity": escaped_defects_after_capacity,
            "escaped_defects_overflow": escaped_defects_overflow,
        },
        "unresolved_blocker_count": unresolved_blocker_count,
        "customer_visible_scope_units": customer_visible_scope_units,
        "incremental_spend": incremental_spend,
        "incremental_spend_components": {
            "incremental_recovery_spend": incremental_recovery_spend,
            "incremental_borrowed_spend": incremental_borrowed_spend,
        },
        "modeled_90_day_margin": modeled_90_day_margin,
        "margin_bridge": {
            "synthetic_labels": {
                "revenue_assumption_unverified": True,
                "cost_inputs_unverified": True,
                "all_values_are_synthetic": True,
            },
            "revenue_base": revenue_base,
            "value_delivered": value_delivered_total,
            "cost_execution": execution_cost,
            "cost_incidents": incident_cost,
            "cost_escaped_defects": escaped_defect_cost,
            "cost_recovery": recovery_cost,
            "total_cost": total_cost_value,
        },
        "model_documentation": {
            "notes": "All defect-count, schedule, capacity, blockers, spend, and margin arithmetic is deterministic and computed from explicit formulas in code.",
            "synthetic_or_unverified_inputs": [
                "V_per_unit",
                "value_decay_per_delay_week",
                "internal_cost_engineering_per_hour",
                "internal_cost_qa_per_hour",
                "cost_per_incident",
                "cost_per_escaped_high_sev_defect",
                "delay_penalty_weeks_on_failure",
                "Sp_policy_*",
            ],
        },
    }

    return SimulationResult(choice=choice, infeasible_for_release=infeasible, gate_status=gate_status, derived=result_derived)
