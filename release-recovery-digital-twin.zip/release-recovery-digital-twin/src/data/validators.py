from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Dict, Iterable, List, Optional


def parse_iso_date(value: Any, *, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be ISO date string")
    # Validate format deterministically.
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except Exception:
        raise ValueError(f"{field} must be YYYY-MM-DD; got={value!r}")
    return value


def validate_scope_class(v: Any) -> str:
    if not isinstance(v, str) or not v:
        raise ValueError("scope_class must be non-empty string")
    return v


def validate_status_one_of(v: Any, *, field: str, allowed: Iterable[str]) -> str:
    if not isinstance(v, str):
        raise ValueError(f"{field} must be string")
    if v not in allowed:
        raise ValueError(f"{field} must be one of {sorted(allowed)}; got={v!r}")
    return v


def validate_nonneg_number(v: Any, *, field: str) -> float:
    try:
        x = float(v)
    except Exception:
        raise ValueError(f"{field} must be a number")
    if x < 0:
        raise ValueError(f"{field} must be >= 0")
    return x


def validate_positive_number(v: Any, *, field: str) -> float:
    x = validate_nonneg_number(v, field=field)
    if x <= 0:
        raise ValueError(f"{field} must be > 0")
    return x


def validate_bool_or_none(v: Any) -> Optional[bool]:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    raise ValueError("completed_on_time must be bool or null")


def validate_json_array_of_strings(v: Any, *, field: str) -> List[str]:
    if not isinstance(v, list):
        raise ValueError(f"{field} must be a list")
    out: List[str] = []
    for i in v:
        if not isinstance(i, str):
            raise ValueError(f"{field} entries must be strings")
        out.append(i)
    return out
