import json
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Iterator, Optional, Sequence, Tuple


@dataclass(frozen=True)
class DbConfig:
    db_path: str


def _connect(cfg: DbConfig) -> sqlite3.Connection:
    conn = sqlite3.connect(cfg.db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def connect(cfg: DbConfig) -> Iterator[sqlite3.Connection]:
    conn = _connect(cfg)
    try:
        yield conn
    finally:
        conn.close()


def ensure_schema(conn: sqlite3.Connection) -> None:
    """Create tables if they do not exist.

    Baseline seed tables (immutable): *baseline_*.
    User scenario tables (editable): *scenario_* and *scenario_snapshot_*.
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS baseline_scenario_meta (
            id TEXT PRIMARY KEY,
            scenario_date TEXT NOT NULL,
            planned_release_date TEXT NOT NULL,
            high_volume_season_date TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS baseline_release_work_items (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            scope_class TEXT NOT NULL,
            status TEXT NOT NULL,
            due_date TEXT NOT NULL,
            completed_at TEXT,
            completed_on_time INTEGER,
            estimated_remaining_effort_hours REAL NOT NULL,
            dependencies_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS baseline_release_incidents (
            id TEXT PRIMARY KEY,
            occurred_at TEXT NOT NULL,
            severity TEXT NOT NULL,
            customer_journey TEXT NOT NULL,
            status TEXT NOT NULL,
            resolved_at TEXT,
            affected_areas_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS baseline_escaped_defects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            status TEXT NOT NULL,
            release_blocker INTEGER NOT NULL,
            severity TEXT NOT NULL,
            discovered_at TEXT NOT NULL,
            verified_at TEXT
        );

        CREATE TABLE IF NOT EXISTS baseline_capacity_allocation_weekly (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            engineer_id TEXT NOT NULL,
            engineer_name TEXT NOT NULL,
            support_hours_per_week REAL NOT NULL,
            release_hours_per_week REAL NOT NULL,
            total_hours_per_week REAL NOT NULL,
            week_start_date TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS baseline_synthetic_assumptions (
            id TEXT PRIMARY KEY,
            assumptions_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS scenario (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            scenario_date TEXT NOT NULL,
            planned_release_date TEXT NOT NULL,
            seed_baseline_meta_id TEXT NOT NULL,
            assumptions_json TEXT NOT NULL,
            FOREIGN KEY (seed_baseline_meta_id) REFERENCES baseline_scenario_meta(id)
        );

        CREATE TABLE IF NOT EXISTS scenario_snapshot (
            id TEXT PRIMARY KEY,
            scenario_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            snapshot_label TEXT NOT NULL,
            snapshot_json TEXT NOT NULL,
            FOREIGN KEY (scenario_id) REFERENCES scenario(id)
        );

        CREATE INDEX IF NOT EXISTS idx_scenario_snapshot_scenario_id
        ON scenario_snapshot(scenario_id);

        -- Evidence recording (human-recorded; sliders/AI must not mark verified)
        CREATE TABLE IF NOT EXISTS evidence_defect_verification (
            scenario_id TEXT NOT NULL,
            defect_id TEXT NOT NULL,
            verified_closed INTEGER NOT NULL,
            verifier_name TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            recorded_by TEXT NOT NULL,
            PRIMARY KEY (scenario_id, defect_id),
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS evidence_defect_risk_acceptance (
            scenario_id TEXT NOT NULL,
            defect_id TEXT NOT NULL,
            accepted_by INTEGER NOT NULL,
            risk_owner_name TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            recorded_by TEXT NOT NULL,
            PRIMARY KEY (scenario_id, defect_id),
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS evidence_regression_tests (
            scenario_id TEXT PRIMARY KEY,
            passed INTEGER NOT NULL,
            test_run_id TEXT,
            build_id TEXT,
            recorded_at TEXT NOT NULL,
            recorded_by TEXT NOT NULL,
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS evidence_rollback_monitoring (
            scenario_id TEXT PRIMARY KEY,
            rollback_tested INTEGER NOT NULL,
            monitoring_available INTEGER NOT NULL,
            on_call_owner TEXT,
            recorded_at TEXT NOT NULL,
            recorded_by TEXT NOT NULL,
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS evidence_customer_approvals (
            scenario_id TEXT PRIMARY KEY,
            customer_accepted INTEGER NOT NULL,
            account_approver TEXT,
            release_approver TEXT,
            recorded_at TEXT NOT NULL,
            recorded_by TEXT NOT NULL,
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS commitment_decision (
            scenario_id TEXT PRIMARY KEY,
            authorized_human_name TEXT NOT NULL,
            authorized_human_role TEXT NOT NULL,
            decision_status TEXT NOT NULL,
            decision_timestamp TEXT NOT NULL,
            candidate_window_start_weeks REAL,
            candidate_window_end_weeks REAL,
            FOREIGN KEY (scenario_id) REFERENCES scenario(id) ON DELETE CASCADE
        );
        """
    )


def baseline_is_seeded(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        "SELECT 1 FROM baseline_scenario_meta LIMIT 1"
    ).fetchone()
    return row is not None


def upsert_baseline_meta(conn: sqlite3.Connection, meta: Dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT OR REPLACE INTO baseline_scenario_meta
            (id, scenario_date, planned_release_date, high_volume_season_date, created_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            meta["scenario_id"],
            meta["scenario_date"],
            meta["planned_release_date"],
            meta["high_volume_season_date"],
            meta.get("created_at", datetime.utcnow().isoformat()),
        ),
    )


def insert_baseline_work_items(conn: sqlite3.Connection, items: Sequence[Dict[str, Any]]) -> None:
    conn.executemany(
        """
        INSERT OR REPLACE INTO baseline_release_work_items
            (id, name, scope_class, status, due_date, completed_at, completed_on_time,
             estimated_remaining_effort_hours, dependencies_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                it["id"],
                it["name"],
                it["scope_class"],
                it["status"],
                it["due_date"],
                it.get("completed_at"),
                None if it.get("completed_on_time") is None else int(bool(it["completed_on_time"])),
                float(it["estimated_remaining_effort_hours"]),
                json.dumps(it.get("dependencies", []), separators=(",", ":")),
            )
            for it in items
        ],
    )


def insert_baseline_incidents(conn: sqlite3.Connection, incidents: Sequence[Dict[str, Any]]) -> None:
    conn.executemany(
        """
        INSERT OR REPLACE INTO baseline_release_incidents
            (id, occurred_at, severity, customer_journey, status, resolved_at, affected_areas_json)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                inc["id"],
                inc["occurred_at"],
                inc["severity"],
                inc["customer_journey"],
                inc["status"],
                inc.get("resolved_at"),
                json.dumps(inc.get("affected_areas", []), separators=(",", ":")),
            )
            for inc in incidents
        ],
    )


def insert_baseline_defects(conn: sqlite3.Connection, defects: Sequence[Dict[str, Any]]) -> None:
    conn.executemany(
        """
        INSERT OR REPLACE INTO baseline_escaped_defects
            (id, name, status, release_blocker, severity, discovered_at, verified_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                d["id"],
                d["name"],
                d["status"],
                int(bool(d["release_blocker"])),
                d["severity"],
                d["discovered_at"],
                d.get("verified_at"),
            )
            for d in defects
        ],
    )


def insert_baseline_capacity_weekly(
    conn: sqlite3.Connection,
    week_start_date: str,
    engineer_capacity_records: Sequence[Dict[str, Any]],
) -> None:
    conn.executemany(
        """
        INSERT INTO baseline_capacity_allocation_weekly
            (engineer_id, engineer_name, support_hours_per_week, release_hours_per_week,
             total_hours_per_week, week_start_date)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        [
            (
                rec["engineer_id"],
                rec["engineer_name"],
                float(rec["support_hours_per_week"]),
                float(rec["release_hours_per_week"]),
                float(rec["total_hours_per_week"]),
                week_start_date,
            )
            for rec in engineer_capacity_records
        ],
    )


def insert_baseline_synthetic_assumptions(conn: sqlite3.Connection, assumptions_file: Dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT OR REPLACE INTO baseline_synthetic_assumptions (id, assumptions_json)
        VALUES (?, ?)
        """,
        ("unverified_monthly_contract_revenue", json.dumps(assumptions_file, separators=(",", ":"))),
    )


def reset_scenario_data(conn: sqlite3.Connection) -> None:
    """Explicit reset action: delete scenarios and snapshots.

    Baseline tables remain immutable.
    """
    conn.execute("DELETE FROM scenario_snapshot")
    conn.execute("DELETE FROM scenario")


def create_scenario(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    name: str,
    description: Optional[str],
    scenario_date: str,
    planned_release_date: str,
    seed_baseline_meta_id: str,
    assumptions_json: Dict[str, Any],
) -> None:
    conn.execute(
        """
        INSERT INTO scenario
            (id, created_at, name, description, scenario_date, planned_release_date,
             seed_baseline_meta_id, assumptions_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            scenario_id,
            datetime.utcnow().isoformat(),
            name,
            description,
            scenario_date,
            planned_release_date,
            seed_baseline_meta_id,
            json.dumps(assumptions_json, separators=(",", ":")),
        ),
    )


def upsert_commitment_decision(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    authorized_human_name: str,
    authorized_human_role: str,
    decision_status: str,
    decision_timestamp: str,
    candidate_window_start_weeks: float,
    candidate_window_end_weeks: float,
) -> None:
    conn.execute(
        """
        INSERT INTO commitment_decision
            (scenario_id, authorized_human_name, authorized_human_role, decision_status, decision_timestamp,
             candidate_window_start_weeks, candidate_window_end_weeks)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id) DO UPDATE SET
            authorized_human_name=excluded.authorized_human_name,
            authorized_human_role=excluded.authorized_human_role,
            decision_status=excluded.decision_status,
            decision_timestamp=excluded.decision_timestamp,
            candidate_window_start_weeks=excluded.candidate_window_start_weeks,
            candidate_window_end_weeks=excluded.candidate_window_end_weeks
        """,
        (
            scenario_id,
            authorized_human_name,
            authorized_human_role,
            decision_status,
            decision_timestamp,
            candidate_window_start_weeks,
            candidate_window_end_weeks,
        ),
    )


def get_commitment_decision(conn: sqlite3.Connection, scenario_id: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM commitment_decision WHERE scenario_id = ?", (scenario_id,)).fetchone()
    return dict(row) if row else None


def upsert_evidence_defect_verification(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    defect_id: str,
    verified_closed: bool,
    verifier_name: str,
    recorded_at: str,
    recorded_by: str,
) -> None:
    conn.execute(
        """
        INSERT INTO evidence_defect_verification
            (scenario_id, defect_id, verified_closed, verifier_name, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id, defect_id) DO UPDATE SET
            verified_closed=excluded.verified_closed,
            verifier_name=excluded.verifier_name,
            recorded_at=excluded.recorded_at,
            recorded_by=excluded.recorded_by
        """,
        (scenario_id, defect_id, int(bool(verified_closed)), verifier_name, recorded_at, recorded_by),
    )


def upsert_evidence_defect_risk_acceptance(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    defect_id: str,
    accepted_by: int,
    risk_owner_name: str,
    recorded_at: str,
    recorded_by: str,
) -> None:
    conn.execute(
        """
        INSERT INTO evidence_defect_risk_acceptance
            (scenario_id, defect_id, accepted_by, risk_owner_name, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id, defect_id) DO UPDATE SET
            accepted_by=excluded.accepted_by,
            risk_owner_name=excluded.risk_owner_name,
            recorded_at=excluded.recorded_at,
            recorded_by=excluded.recorded_by
        """,
        (scenario_id, defect_id, accepted_by, risk_owner_name, recorded_at, recorded_by),
    )


def upsert_evidence_regression_tests(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    passed: bool,
    test_run_id: Optional[str],
    build_id: Optional[str],
    recorded_at: str,
    recorded_by: str,
) -> None:
    conn.execute(
        """
        INSERT INTO evidence_regression_tests
            (scenario_id, passed, test_run_id, build_id, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id) DO UPDATE SET
            passed=excluded.passed,
            test_run_id=excluded.test_run_id,
            build_id=excluded.build_id,
            recorded_at=excluded.recorded_at,
            recorded_by=excluded.recorded_by
        """,
        (scenario_id, int(bool(passed)), test_run_id, build_id, recorded_at, recorded_by),
    )


def upsert_evidence_rollback_monitoring(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    rollback_tested: bool,
    monitoring_available: bool,
    on_call_owner: str,
    recorded_at: str,
    recorded_by: str,
) -> None:
    conn.execute(
        """
        INSERT INTO evidence_rollback_monitoring
            (scenario_id, rollback_tested, monitoring_available, on_call_owner, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id) DO UPDATE SET
            rollback_tested=excluded.rollback_tested,
            monitoring_available=excluded.monitoring_available,
            on_call_owner=excluded.on_call_owner,
            recorded_at=excluded.recorded_at,
            recorded_by=excluded.recorded_by
        """,
        (
            scenario_id,
            int(bool(rollback_tested)),
            int(bool(monitoring_available)),
            on_call_owner,
            recorded_at,
            recorded_by,
        ),
    )


def upsert_evidence_customer_approvals(
    conn: sqlite3.Connection,
    *,
    scenario_id: str,
    customer_accepted: bool,
    account_approver: Optional[str],
    release_approver: Optional[str],
    recorded_at: str,
    recorded_by: str,
) -> None:
    conn.execute(
        """
        INSERT INTO evidence_customer_approvals
            (scenario_id, customer_accepted, account_approver, release_approver, recorded_at, recorded_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT (scenario_id) DO UPDATE SET
            customer_accepted=excluded.customer_accepted,
            account_approver=excluded.account_approver,
            release_approver=excluded.release_approver,
            recorded_at=excluded.recorded_at,
            recorded_by=excluded.recorded_by
        """,
        (
            scenario_id,
            int(bool(customer_accepted)),
            account_approver,
            release_approver,
            recorded_at,
            recorded_by,
        ),
    )


def save_scenario_snapshot(
    conn: sqlite3.Connection,
    *,
    snapshot_id: str,
    scenario_id: str,
    snapshot_label: str,
    snapshot_json: Dict[str, Any],
) -> None:
    conn.execute(
        """
        INSERT INTO scenario_snapshot
            (id, scenario_id, created_at, snapshot_label, snapshot_json)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            snapshot_id,
            scenario_id,
            datetime.utcnow().isoformat(),
            snapshot_label,
            json.dumps(snapshot_json, separators=(",", ":")),
        ),
    )


def load_baseline(conn: sqlite3.Connection) -> Dict[str, Any]:
    """Load baseline data into python dicts for deterministic simulation."""
    meta = conn.execute("SELECT * FROM baseline_scenario_meta LIMIT 1").fetchone()
    if meta is None:
        raise RuntimeError("Baseline not seeded")

    work_items = conn.execute("SELECT * FROM baseline_release_work_items").fetchall()
    incidents = conn.execute("SELECT * FROM baseline_release_incidents").fetchall()
    defects = conn.execute("SELECT * FROM baseline_escaped_defects").fetchall()
    capacity = conn.execute("SELECT * FROM baseline_capacity_allocation_weekly").fetchall()
    assumptions_row = conn.execute("SELECT * FROM baseline_synthetic_assumptions").fetchone()

    def row_to_dict(r: sqlite3.Row) -> Dict[str, Any]:
        return {k: r[k] for k in r.keys()}

    return {
        "meta": row_to_dict(meta),
        "work_items": [row_to_dict(r) for r in work_items],
        "incidents": [row_to_dict(r) for r in incidents],
        "defects": [row_to_dict(r) for r in defects],
        "capacity": [row_to_dict(r) for r in capacity],
        "synthetic_assumptions": json.loads(assumptions_row["assumptions_json"]) if assumptions_row else {},
    }


def load_scenario(conn: sqlite3.Connection, scenario_id: str) -> Dict[str, Any]:
    row = conn.execute("SELECT * FROM scenario WHERE id = ?", (scenario_id,)).fetchone()
    if row is None:
        raise KeyError(f"Unknown scenario_id={scenario_id}")
    return dict(row)
