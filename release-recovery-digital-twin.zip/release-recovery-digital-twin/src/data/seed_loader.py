import json
from pathlib import Path
from typing import Any, Dict


class SeedLoaderError(RuntimeError):
    pass


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise SeedLoaderError(f"Failed to read JSON: {path}: {e}")


def seed_baseline_from_json_files(db_conn, data_dir: Path) -> None:
    """Seed baseline tables from synthetic seed JSON files.

    Safety requirement:
    - Caller must ensure DB is empty (baseline not seeded) before calling.
    - Never overwrite user scenarios/snapshots.
    """
    # Local import to avoid circular deps.
    from .db import (
        insert_baseline_capacity_weekly,
        insert_baseline_defects,
        insert_baseline_incidents,
        insert_baseline_synthetic_assumptions,
        insert_baseline_work_items,
        upsert_baseline_meta,
    )

    meta = _read_json(data_dir / "scenario_meta.json")
    work_items_doc = _read_json(data_dir / "release_work_items.json")
    incidents_doc = _read_json(data_dir / "release_incidents.json")
    defects_doc = _read_json(data_dir / "escaped_defects.json")
    capacity_doc = _read_json(data_dir / "capacity_allocation_weekly.json")
    assumptions_doc = _read_json(data_dir / "synthetic_monthly_assumptions.json")

    with db_conn:
        upsert_baseline_meta(db_conn, meta)
        insert_baseline_work_items(db_conn, work_items_doc["work_items"])
        insert_baseline_incidents(db_conn, incidents_doc["incidents"])
        insert_baseline_defects(db_conn, defects_doc["escaped_defects"])
        insert_baseline_capacity_weekly(
            db_conn,
            capacity_doc["week_start_date"],
            capacity_doc["engineer_capacity_records"],
        )
        insert_baseline_synthetic_assumptions(db_conn, assumptions_doc)
