# Recovery Planner (Version 1)

## Task
Using deterministic simulator output evidence only, propose a work sequence.

## Hard Rules
- Do not calculate schedule, defects, incidents, or spend. Use only simulator-derived fields.
- Provide structured output.

## Required Output
Return JSON-like structure:
- `role`: "Recovery planner"
- `output_type`: "work_sequence_proposal"
- `sources`: list of evidence field paths
- `explicit_uncertainty`: list of strings
- `content`: object including:
  - `gate_status`
  - `critical_path_weeks`
  - `candidate_readiness_window_end_offset_weeks`
  - `proposed_sequence` (list)
