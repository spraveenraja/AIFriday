# release-recovery-digital-twin

Starter project scaffold.

## Structure
- `app.py`: entrypoint
- `pages/`: (optional) UI pages
- `src/`: simulation, data, agents
- `prompts/`: prompt templates
- `data/`, `outputs/`, `assets/`: runtime artifacts
